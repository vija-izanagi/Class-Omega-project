"""Run Sentinel against local CSV datasets, NAB labels, or a synthetic stream."""

import argparse
import io
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

if __package__:
    from .nab_evaluator import NABEvaluator
    from .sentinel import SentinelConfig, SentinelDetector
else:
    from nab_evaluator import NABEvaluator
    from sentinel import SentinelConfig, SentinelDetector


def read_nab_csv(path):
    path = Path(path)
    return read_nab_csv_bytes(path.read_bytes(), str(path))


def read_nab_csv_bytes(content, source_name="uploaded CSV"):
    if not content:
        raise ValueError(f"{source_name} is empty.")
    first_line = content.splitlines()[0].decode("utf-8-sig")
    first_row = [part.strip().lower() for part in first_line.split(",")]
    has_header = first_row[:2] == ["timestamp", "value"]
    frame = pd.read_csv(
        io.BytesIO(content),
        header=0 if has_header else None,
        names=None if has_header else ["timestamp", "value"],
        usecols=["timestamp", "value"] if has_header else [0, 1],
        dtype={"timestamp": "string", "value": "float64"} if has_header else None,
        engine="c",
        skipinitialspace=True,
    )
    if not has_header:
        frame.columns = ["timestamp", "value"]
        frame["timestamp"] = frame["timestamp"].astype("string")
        frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    if len(frame) < 2:
        raise ValueError(f"{source_name} contains fewer than two finite values.")
    values = frame["value"].to_numpy(dtype=np.float64, copy=False)
    valid = np.isfinite(values)
    timestamps = frame.loc[valid, "timestamp"].astype(str).tolist()
    values = values[valid]
    if len(values) < 2:
        raise ValueError(f"{source_name} contains fewer than two finite values.")
    return timestamps, values


def default_dataset_dir():
    """Find the nearest workspace ancestor containing the dataset CSV files."""
    source_path = Path(__file__).resolve()
    for parent in source_path.parents:
        candidate = parent / "dataset"
        if candidate.is_dir() and any(
            path
            for path in candidate.rglob("*.csv")
            if not path.name.startswith("._")
        ):
            return candidate
    return source_path.parents[1] / "dataset"


def event_windows(timestamps, anomaly_timestamps, fraction):
    time_to_index = {timestamp: index for index, timestamp in enumerate(timestamps)}
    missing = [stamp for stamp in anomaly_timestamps if stamp not in time_to_index]
    if missing:
        raise ValueError(
            f"{len(missing)} NAB label timestamp(s) do not match the CSV; "
            f"first missing timestamp: {missing[0]}"
        )
    lookback = max(1, int(math.ceil(len(timestamps) * fraction)))
    windows = []
    for stamp in anomaly_timestamps:
        end = time_to_index[stamp]
        windows.append((max(0, end - lookback), end))
    return sorted(set(windows))


def run_stream(
    timestamps,
    values,
    train_size,
    windows,
    epochs,
    threshold_percentile,
    event_onsets=None,
):
    if train_size < 60 or train_size >= len(values):
        raise ValueError(
            f"Need at least 60 warm-up rows and one test row; got {train_size} "
            f"of {len(values)}."
        )
    test_windows = [
        (max(0, start - train_size), end - train_size)
        for start, end in windows
        if end >= train_size
    ]
    test_onsets = (
        [onset - train_size for onset in event_onsets if onset >= train_size]
        if event_onsets is not None
        else None
    )
    if any(start < train_size for start, _ in windows):
        raise ValueError("Anomaly window overlaps training; reduce the train fraction.")

    config = SentinelConfig(
        training_epochs=epochs,
        threshold_percentile=threshold_percentile,
    )
    training_started = time.perf_counter()
    detector = SentinelDetector(
        config,
        {
            "timestamp": timestamps[:train_size],
            "value": values[:train_size],
        },
    )
    training_seconds = time.perf_counter() - training_started
    detections = []
    latencies_ms = []
    try:
        for index in range(train_size, len(values)):
            started = time.perf_counter()
            result = detector.process_step(timestamps[index], float(values[index]))
            latencies_ms.append((time.perf_counter() - started) * 1000.0)
            if result.is_anomalous:
                detections.append(index - train_size)
    finally:
        detector.stop()
    if len(latencies_ms) != len(values) - train_size:
        raise RuntimeError("Not every test observation was processed.")
    metrics = NABEvaluator().evaluate(
        detections,
        test_windows,
        len(values) - train_size,
        event_onsets=test_onsets,
    )
    if test_onsets is not None:
        delay_seconds = []
        for detection_index, onset_index in metrics["Detection_Delay_Pairs"]:
            detection_text = str(timestamps[train_size + detection_index])
            onset_text = str(timestamps[train_size + onset_index])
            if detection_text.isdigit() or onset_text.isdigit():
                continue
            detection_time = pd.to_datetime(detection_text, errors="coerce")
            onset_time = pd.to_datetime(onset_text, errors="coerce")
            if pd.isna(detection_time) or pd.isna(onset_time):
                continue
            delay_seconds.append(
                max(0.0, (detection_time - onset_time).total_seconds())
            )
        metrics["Detection_Delays_Seconds"] = delay_seconds
    metrics["latencies_ms"] = latencies_ms
    metrics["processed_rows"] = len(latencies_ms)
    metrics["adaptation_count"] = detector.adaptation_count
    metrics["active_threshold"] = detector.threshold
    metrics["training_seconds"] = training_seconds
    return metrics


def synthetic_stream(length, seed):
    if length < 1000:
        raise ValueError("Synthetic stream length must be at least 1,000.")
    rng = np.random.default_rng(seed)
    innovations = rng.normal(0.0, 0.12, length)
    correlated_noise = np.empty(length, dtype=float)
    correlated_noise[0] = innovations[0]
    for index in range(1, length):
        correlated_noise[index] = (
            0.96 * correlated_noise[index - 1] + innovations[index]
        )
    slow_drift = np.cumsum(rng.normal(0.0, 0.0015, length))
    values = 10.0 + slow_drift + correlated_noise + rng.normal(0.0, 0.08, length)
    timestamps = [str(index) for index in range(length)]

    warmup = max(200, int(length * 0.1))
    event_count = max(4, min(50, length // 2000))
    spacing = (length - warmup - 300) // event_count
    starts = (
        warmup
        + 100
        + np.arange(event_count) * spacing
        + rng.integers(0, max(1, spacing // 2), size=event_count)
    ).astype(int)
    windows = []
    for event_index, start in enumerate(starts):
        kind = event_index % 5
        duration = max(10, min(100, length // 500))
        end = min(length - 1, int(start) + duration)
        windows.append((int(start), end))
        if kind == 0:
            values[start] += rng.choice([-1.0, 1.0]) * rng.uniform(12, 25)
        elif kind == 1:
            values[start : end + 1] += rng.choice([-1.0, 1.0]) * rng.uniform(3, 7)
        elif kind == 2:
            duration_points = end - start + 1
            local_innovations = rng.normal(0.0, 0.2, duration_points)
            contextual = np.cumsum(local_innovations)
            values[start : end + 1] += contextual + rng.choice([-1.0, 1.0]) * 2.0
        elif kind == 3:
            values[start : end + 1] = float(np.mean(values[max(0, start - 20) : start]))
        else:
            values[start : end + 1] += rng.normal(
                0.0, 4.0, end - start + 1
            )
    return timestamps, values, warmup, windows


def evaluate_synthetic(args):
    loading_started = time.perf_counter()
    timestamps, values, train_size, windows = synthetic_stream(
        args.synthetic_length, args.seed
    )
    data_load_seconds = time.perf_counter() - loading_started
    results = [
        run_stream(
            timestamps,
            values,
            train_size,
            windows,
            args.epochs,
            args.threshold_percentile,
            event_onsets=[start for start, _ in windows],
        )
    ]
    results[0]["data_load_seconds"] = data_load_seconds
    return results, len(values), train_size


def evaluate_nab(args):
    data_dir = Path(args.data_dir)
    if not data_dir.is_dir():
        raise ValueError(f"NAB data directory does not exist: {data_dir}")
    labels = {}
    if args.labels:
        labels_path = Path(args.labels)
        if not labels_path.is_file():
            raise ValueError(f"NAB labels JSON does not exist: {labels_path}")
        with labels_path.open(encoding="utf-8") as file:
            labels = json.load(file)

    files = sorted(
        path for path in data_dir.rglob("*.csv") if not path.name.startswith("._")
    )
    if not files:
        raise ValueError(f"No CSV files found under {data_dir}.")
    metrics_by_file = []
    total_rows = 0
    total_training_rows = 0
    for path in files:
        relative = path.relative_to(data_dir).as_posix()
        loading_started = time.perf_counter()
        timestamps, values = read_nab_csv(path)
        data_load_seconds = time.perf_counter() - loading_started
        windows = event_windows(
            timestamps, labels.get(relative, []), args.window_fraction
        )
        onset_lookup = {timestamp: index for index, timestamp in enumerate(timestamps)}
        event_onsets = sorted(
            {onset_lookup[timestamp] for timestamp in labels.get(relative, [])}
        )
        train_size = max(60, int(len(values) * args.train_fraction))
        first_anomaly = min((start for start, _ in windows), default=len(values))
        train_size = min(train_size, first_anomaly)
        if train_size < 60 or train_size >= len(values):
            print(f"SKIP {relative}: insufficient uncontaminated warm-up rows")
            continue
        result = run_stream(
            timestamps,
            values,
            train_size,
            windows,
            args.epochs,
            args.threshold_percentile,
            event_onsets=event_onsets if args.labels else None,
        )
        result["file"] = relative
        result["data_load_seconds"] = data_load_seconds
        metrics_by_file.append(result)
        total_rows += len(values)
        total_training_rows += train_size
        if args.labels:
            print(
                f"{relative}: events={result['Total_Events']} "
                f"TP={result['TP']} FP={result['FP']} FN={result['FN']} "
                f"F1={result['Event_F1']:.3f}"
            )
        else:
            print(
                f"{relative}: observations={len(values):,} "
                f"anomaly episodes={result['Detection_Episodes']}"
            )
    if not metrics_by_file:
        raise ValueError("No NAB files could be evaluated with the selected settings.")
    return metrics_by_file, total_rows, total_training_rows


def report(results, total_rows, training_rows):
    tp = sum(result["TP"] for result in results)
    fp = sum(result["FP"] for result in results)
    fn = sum(result["FN"] for result in results)
    events = sum(result["Total_Events"] for result in results)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / events if events else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    delays = [
        delay
        for result in results
        for delay in result["Detection_Delays"]
    ]
    delays_seconds = [
        delay
        for result in results
        for delay in result.get("Detection_Delays_Seconds", [])
    ]
    latencies = np.concatenate(
        [np.asarray(result["latencies_ms"], dtype=float) for result in results]
    )
    print("\nSentinel benchmark summary")
    print(
        f"Files={len(results)} rows={total_rows:,} training_rows={training_rows:,} "
        f"events={events}"
    )
    processed_rows = sum(result["processed_rows"] for result in results)
    print(
        f"Test observations processed={processed_rows:,}/"
        f"{total_rows - training_rows:,}"
    )
    print(
        f"Dataset loading={sum(result.get('data_load_seconds', 0.0) for result in results):.3f}s "
        f"offline model fitting={sum(result.get('training_seconds', 0.0) for result in results):.3f}s"
    )
    if events:
        print(
            f"TP={tp} FP={fp} FN={fn} | event precision={precision:.3f} "
            f"recall={recall:.3f} F1={f1:.3f}"
        )
        print(
            f"Mean detection delay={np.mean(delays):.2f} samples"
            if delays
            else "Mean detection delay=n/a"
        )
        if delays_seconds:
            print(
                f"Mean detection delay from labeled onset="
                f"{np.mean(delays_seconds):.2f} seconds"
            )
    else:
        anomaly_episodes = sum(
            result.get("Detection_Episodes", 0) for result in results
        )
        print(
            "No labels supplied; event precision/recall/F1 are unavailable. "
            f"Detected anomaly episodes={anomaly_episodes}"
        )
    if results and "adaptation_count" in results[0]:
        print(
            f"Baseline adaptations={sum(result['adaptation_count'] for result in results)} "
            f"active threshold={results[-1]['active_threshold']:.3f}"
        )
    print(
        f"Inference mean={np.mean(latencies):.3f} ms p95="
        f"{np.percentile(latencies, 95):.3f} ms max={np.max(latencies):.3f} ms "
        f">5ms points={np.count_nonzero(latencies >= 5.0):,}"
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Train/evaluate Sentinel using CSVs in the dataset folder by default; "
            "optional NAB labels and synthetic stress testing are supported."
        )
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--data-dir",
        help=(
            "Folder recursively scanned for timestamp,value CSV files. Defaults "
            "to the workspace's dataset folder."
        ),
    )
    mode.add_argument(
        "--synthetic-length",
        type=int,
        nargs="?",
        const=500_000,
        help=(
            "Optional synthetic stress test; retained for benchmarking only, "
            "not used by default."
        ),
    )
    parser.add_argument(
        "--labels",
        help="Optional NAB combined_labels.json for event-level metrics.",
    )
    parser.add_argument(
        "--train-fraction",
        type=float,
        default=0.2,
        help="Fraction of each CSV reserved for initial model fitting.",
    )
    parser.add_argument(
        "--window-fraction",
        type=float,
        default=0.1,
        help="Fractional lookback before each NAB labeled timestamp.",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=30,
        help="Maximum autoencoder epochs; held-out validation enables early stopping.",
    )
    parser.add_argument(
        "--threshold-percentile",
        type=float,
        default=99.95,
        help=(
            "Threshold quantile; stricter thresholds reduce false alarms."
        ),
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    if not 0.0 < args.train_fraction < 1.0:
        parser.error("--train-fraction must be between 0 and 1.")
    if not 0.0 < args.window_fraction < 1.0:
        parser.error("--window-fraction must be between 0 and 1.")
    if args.epochs < 1:
        parser.error("--epochs must be positive.")
    if not 0.0 < args.threshold_percentile < 100.0:
        parser.error("--threshold-percentile must be between 0 and 100.")
    if args.data_dir or args.synthetic_length is None:
        if args.labels and not args.data_dir:
            parser.error("--labels can only be used with --data-dir.")
        if not args.data_dir:
            args.data_dir = str(default_dataset_dir())
        results, total_rows, training_rows = evaluate_nab(args)
    else:
        results, total_rows, training_rows = evaluate_synthetic(args)
    report(results, total_rows, training_rows)


if __name__ == "__main__":
    main()
