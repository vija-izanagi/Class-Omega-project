import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import numpy as np
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

if __package__:
    from .run_nab_benchmark import (
        default_dataset_dir,
        read_nab_csv,
        read_nab_csv_bytes,
    )
    from .sentinel import SentinelConfig, SentinelDetector
else:
    from run_nab_benchmark import default_dataset_dir, read_nab_csv, read_nab_csv_bytes
    from sentinel import SentinelConfig, SentinelDetector

detector: Optional[SentinelDetector] = None
stream_step = 0
stream_timestamps: list[str] = []
stream_values = np.empty(0, dtype=np.float64)
stream_index = 0
warmup_values = np.empty(0, dtype=np.float64)
warmup_timestamps: list[str] = []
warmup_size = 0
stream_dataset_name = "Loading dataset"
pending_payload: Optional[str] = None
pending_index = 0
STREAM_DELAY_SECONDS = 0.05
stream_lock = asyncio.Lock()
logger = logging.getLogger(__name__)


def create_dashboard_detector(
    training_values: np.ndarray,
    training_timestamps: Optional[list[str]] = None,
) -> SentinelDetector:
    training_data = training_values
    if training_timestamps is not None:
        training_data = {
            "timestamp": training_timestamps,
            "value": training_values,
        }
    return SentinelDetector(
        SentinelConfig(
            training_epochs=30,
            training_patience=5,
            threshold_percentile=99.0,
        ),
        training_data,
    )


def dataset_warmup_size(observation_count: int) -> int:
    if observation_count < 2:
        raise ValueError("A dataset must contain at least two observations.")
    return min(observation_count - 1, max(60, int(observation_count * 0.2)))


def load_dataset_stream(
    dataset_dir: Optional[Path] = None,
) -> tuple[list[str], np.ndarray, int]:
    if dataset_dir is None:
        configured_path = os.environ.get("SENTINEL_DATASET_PATH")
        dataset_dir = Path(configured_path).expanduser() if configured_path else default_dataset_dir()
    dataset_dir = Path(dataset_dir)
    if not dataset_dir.is_dir():
        if dataset_dir.is_file() and dataset_dir.suffix.lower() == ".csv":
            timestamps, values = read_nab_csv(dataset_dir)
            if values.size < 61:
                raise ValueError(
                    f"Need at least 61 finite dataset observations; found {values.size}."
                )
            return timestamps, values, 1
        raise FileNotFoundError(f"Dataset folder or CSV does not exist: {dataset_dir}")

    csv_files = sorted(
        path for path in dataset_dir.rglob("*.csv") if not path.name.startswith("._")
    )
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found under {dataset_dir}")

    timestamps_all = []
    value_arrays = []
    for csv_path in csv_files:
        timestamps, values = read_nab_csv(csv_path)
        if values.size:
            timestamps_all.extend(timestamps)
            value_arrays.append(values)

    if not value_arrays:
        raise ValueError(f"No finite 'value' observations found in {dataset_dir}")
    values = np.concatenate(value_arrays)
    if values.size < 61:
        raise ValueError(
            f"Need at least 61 finite dataset observations; found {values.size}."
        )
    return timestamps_all, values, len(csv_files)


def reset_completed_stream() -> bool:
    global detector, pending_index, pending_payload, stream_index, stream_step
    if stream_index < len(stream_values):
        return False
    if detector is not None:
        detector.stop()
    detector = create_dashboard_detector(warmup_values, warmup_timestamps)
    stream_index = warmup_size
    stream_step = 0
    pending_payload = None
    pending_index = stream_index
    return True


def activate_dataset(
    name: str,
    timestamps: list[str],
    values: np.ndarray,
    fitted_detector: SentinelDetector,
) -> None:
    global detector, pending_index, pending_payload, stream_dataset_name
    global stream_index, stream_step, stream_timestamps, stream_values
    global warmup_size, warmup_timestamps, warmup_values

    previous_detector = detector
    stream_dataset_name = name
    warmup_size = dataset_warmup_size(len(values))
    warmup_values = values[:warmup_size].copy()
    warmup_timestamps = timestamps[:warmup_size]
    stream_timestamps = timestamps
    stream_values = values
    detector = fitted_detector
    stream_index = warmup_size
    stream_step = 0
    pending_payload = None
    pending_index = stream_index
    if previous_detector is not None and previous_detector is not fitted_detector:
        previous_detector.stop()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    print("Loading CSV training data from the workspace dataset folder...")
    timestamps, values, dataset_file_count = load_dataset_stream()
    selected_warmup_size = dataset_warmup_size(values.size)
    if selected_warmup_size >= values.size:
        raise ValueError("Dataset must contain observations after the warm-up prefix.")
    global detector, stream_step, stream_timestamps, stream_values
    global stream_index, warmup_values, warmup_timestamps, warmup_size
    global stream_dataset_name
    configured_dataset = os.environ.get("SENTINEL_DATASET_PATH")
    if configured_dataset:
        stream_dataset_name = Path(configured_dataset).name or "Custom dataset"
    else:
        stream_dataset_name = "Workspace dataset"
    warmup_values = values[:selected_warmup_size].copy()
    warmup_timestamps = timestamps[:selected_warmup_size]
    warmup_size = selected_warmup_size
    detector = create_dashboard_detector(warmup_values, warmup_timestamps)
    stream_timestamps = timestamps
    stream_values = values
    stream_index = warmup_size
    stream_step = 0
    _app.state.detector = detector
    print(
        f"Model trained using {stream_dataset_name}: up to {warmup_size:,} initial observations "
        f"from {dataset_file_count} CSV file(s), out of {len(values):,} total. "
        f"Streaming from row {warmup_size + 1:,} at "
        f"{1.0 / STREAM_DELAY_SECONDS:.0f} observations per second."
    )
    try:
        yield
    finally:
        if detector is not None:
            detector.stop()


async def receive_dashboard_controls(websocket: WebSocket) -> None:
    while True:
        try:
            message = await websocket.receive_text()
        except WebSocketDisconnect:
            return
        try:
            control = json.loads(message)
        except json.JSONDecodeError:
            logger.warning("Ignoring invalid dashboard control message.")
            continue
        if not isinstance(control, dict):
            logger.warning("Ignoring dashboard control message that is not an object.")
            continue
        if control.get("type") != "score_weights":
            continue
        if detector is None:
            logger.warning("Ignoring score weight update before detector initialization.")
            continue
        try:
            detector.set_autoencoder_weight(control["autoencoder_weight"])
        except (KeyError, TypeError, ValueError, OverflowError):
            logger.warning("Ignoring invalid autoencoder score weight: %r", control)


app = FastAPI(
    title="Sentinel Adaptive Time-Series Anomaly Detection",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/dataset")
async def upload_dataset(request: Request, filename: str = "custom.csv"):
    content = await request.body()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded CSV is empty.")
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="CSV uploads are limited to 50 MB.")

    safe_filename = Path(filename).name
    if not safe_filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Upload a .csv file.")
    try:
        timestamps, values = await asyncio.to_thread(
            read_nab_csv_bytes,
            content,
            safe_filename,
        )
    except (ValueError, UnicodeDecodeError) as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    if len(values) < 61:
        raise HTTPException(
            status_code=400,
            detail=f"CSV must contain at least 61 finite observations; found {len(values)}.",
        )

    selected_warmup_size = dataset_warmup_size(len(values))
    new_detector = await asyncio.to_thread(
        create_dashboard_detector,
        values[:selected_warmup_size],
        timestamps[:selected_warmup_size],
    )
    activate_dataset(safe_filename, timestamps, values, new_detector)
    app.state.detector = new_detector
    return {
        "dataset": stream_dataset_name,
        "observations": len(values),
        "training_observations": warmup_size,
        "streaming_observations": len(values) - warmup_size,
    }


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global pending_index, pending_payload, stream_index, stream_step
    await websocket.accept()
    control_task = asyncio.create_task(receive_dashboard_controls(websocket))

    try:
        async with stream_lock:
            reset_completed_stream()

            while stream_index < len(stream_values):
                if pending_payload is None:
                    index = stream_index
                    t0 = time.perf_counter()
                    if detector is None:
                        raise RuntimeError(
                            "Detector startup calibration did not complete."
                        )
                    result = detector.process_step(
                        stream_timestamps[index], float(stream_values[index])
                    )
                    latency_ms = (time.perf_counter() - t0) * 1000

                    payload = {
                        "time": stream_timestamps[index],
                        "dataset": stream_dataset_name,
                        "latency_ms": latency_ms,
                        "step": stream_step + 1,
                        "row_index": index + 1,
                        "total_rows": len(stream_values),
                        "value": result.value,
                        "loss": result.anomaly_score,
                        "score": result.anomaly_score,
                        "anomaly_score": result.anomaly_score,
                        "threshold": detector.last_decision_threshold,
                        "threshold_floor": detector.config.threshold_floor,
                        "autoencoder_weight": detector.config.autoencoder_weight,
                        "statistical_weight": 1.0 - detector.config.autoencoder_weight,
                        "point_threshold": detector.point_threshold,
                        "detection_mode": detector.detection_mode,
                        "details": detector.last_decision_details,
                        "rolling_variance": detector.last_features["rolling_std"] ** 2,
                        "adaptation_count": detector.adaptation_count,
                        "last_adaptation": detector.last_adaptation,
                        "label": (
                            "ANOMALOUS" if result.is_anomalous else "NORMAL"
                        ),
                        "evidence": result.evidence,
                    }
                    pending_index = index
                    pending_payload = json.dumps(payload)

                await websocket.send_text(pending_payload)
                stream_index = pending_index + 1
                stream_step += 1
                pending_index = stream_index
                pending_payload = None
                await asyncio.sleep(STREAM_DELAY_SECONDS)

            await websocket.close(code=1000, reason="Dataset stream complete")
    except WebSocketDisconnect:
        print("Client disconnected")
    except Exception as e:
        print(f"WebSocket processing failed: {e}")
        await websocket.close(code=1011, reason="Anomaly detection failed")
    finally:
        control_task.cancel()
        try:
            await control_task
        except asyncio.CancelledError:
            pass
