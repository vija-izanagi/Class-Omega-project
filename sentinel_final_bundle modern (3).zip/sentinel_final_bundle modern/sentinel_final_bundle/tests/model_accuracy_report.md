# Sentinel Dataset Evaluation

- Dataset directory: `C:\Users\ethan\OneDrive\Documents\GitHub\Class Omega\dataset`
- CSV files evaluated: 1
- Evaluation source: dataset folder only; no archive, synthetic, or external CSVs.
- Decision rule: score >= active dynamic threshold, followed by the configured point-magnitude gate and low-baseline suppression.

## Reference-label metrics

Accuracy, precision, recall, and F1 are unavailable: no labels are defined for the CSV files in the dataset folder.

## Per-file results

### `art_increase_spike_density.csv`

- Observations: 4,032 (training 806, testing 3,226)
- Threshold crossings: 1,199
- Crossings blocked by point-magnitude gate: 1,198
- Low-baseline suppressions: 1,131
- Reported anomalies: 1
- Zero-valued anomaly alerts: 0
- Threshold/decision consistency checks: 3,226/3,226 passed
- Dynamic threshold: min 0.2673, median 0.2673, max 0.4186, final 0.2673
- Inference latency: mean 0.550 ms, p95 1.195 ms, max 2.593 ms

## Interpretation

A threshold crossing is not silently discarded: the report separately counts crossings that are gated by point magnitude and those suppressed as baseline returns. A threshold candidate is excluded from adaptive normal-score history so a missed/gated candidate cannot raise its own future threshold.
