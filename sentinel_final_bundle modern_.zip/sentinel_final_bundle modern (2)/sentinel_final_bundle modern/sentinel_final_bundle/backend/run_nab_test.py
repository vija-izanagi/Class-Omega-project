"""Backward-compatible entry point for Sentinel's dataset benchmark runner."""

from run_nab_benchmark import main


if __name__ == "__main__":
    main()
