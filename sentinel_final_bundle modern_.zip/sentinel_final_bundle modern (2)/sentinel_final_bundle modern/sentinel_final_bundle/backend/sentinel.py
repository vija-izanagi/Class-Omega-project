"""Fast, persistent hybrid streaming anomaly detection."""

import logging
import math
import os
import pickle
import threading
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Deque, List, Optional, Sequence, Union

import numpy as np
import torch
from torch import nn

logger = logging.getLogger(__name__)
Timestamp = Union[str, datetime]


@dataclass
class SentinelConfig:
    window_size: int = 60
    threshold_percentile: float = 99.0
    ema_alpha: float = 0.1
    autoencoder_weight: float = 0.6
    baseline_tolerance: float = 0.05
    point_threshold_percentile: float = 99.9
    point_cluster_min_count: int = 6
    autoencoder_dims: List[int] = field(default_factory=lambda: [60, 32, 8])
    training_epochs: int = 30
    training_patience: int = 5
    learning_rate: float = 0.001
    score_history_size: int = 1000
    random_state: int = 42
    torch_num_threads: int = 1
    retrain_interval: int = 1000
    enable_background_retraining: bool = True
    adaptation_window: int = 300
    drift_sensitivity: float = 3.0
    variance_change_ratio: float = 0.7
    threshold_floor: float = 0.05

    def __post_init__(self):
        if self.window_size < 2:
            raise ValueError("window_size must be at least 2.")
        if self.window_size != 60 and self.autoencoder_dims == [60, 32, 8]:
            self.autoencoder_dims[0] = self.window_size
        if not 0.0 < self.threshold_percentile < 100.0:
            raise ValueError("threshold_percentile must be between 0 and 100.")
        if not 0.0 < self.ema_alpha <= 1.0:
            raise ValueError("ema_alpha must be in the interval (0, 1].")
        if not 0.0 <= self.autoencoder_weight <= 1.0:
            raise ValueError("autoencoder_weight must be between 0 and 1.")
        if not math.isfinite(self.baseline_tolerance) or self.baseline_tolerance < 0:
            raise ValueError("baseline_tolerance must be finite and non-negative.")
        if not 0.0 < self.point_threshold_percentile <= 100.0:
            raise ValueError("point_threshold_percentile must be in (0, 100].")
        if self.point_cluster_min_count < 1:
            raise ValueError("point_cluster_min_count must be positive.")
        if not self.autoencoder_dims or self.autoencoder_dims[0] != self.window_size:
            raise ValueError(
                "autoencoder_dims must start with the configured window_size."
            )
        if any(dimension < 1 for dimension in self.autoencoder_dims):
            raise ValueError("All autoencoder dimensions must be positive.")
        if (
            self.training_epochs < 1
            or self.training_patience < 1
            or self.score_history_size < 1
        ):
            raise ValueError(
                "training_epochs, training_patience, and score_history_size "
                "must be positive."
            )
        if self.retrain_interval < 1:
            raise ValueError("retrain_interval must be positive.")
        if self.torch_num_threads < 1:
            raise ValueError("torch_num_threads must be positive.")
        if self.adaptation_window < self.window_size * 2:
            raise ValueError("adaptation_window must be at least twice window_size.")
        if self.drift_sensitivity <= 0.0:
            raise ValueError("drift_sensitivity must be positive.")
        if not 0.0 < self.variance_change_ratio < 1.0:
            raise ValueError("variance_change_ratio must be between 0 and 1.")
        if not 0.0 <= self.threshold_floor <= 1.0:
            raise ValueError("threshold_floor must be between 0 and 1.")


@dataclass
class AnomalyResult:
    timestamp: str
    value: float
    anomaly_score: float
    is_anomalous: bool
    evidence: str


class BottleneckAutoencoder(nn.Module):
    def __init__(self, dimensions: Sequence[int]):
        super().__init__()
        encoder = []
        for input_size, output_size in zip(dimensions, dimensions[1:]):
            encoder.extend((nn.Linear(input_size, output_size), nn.ReLU()))
        self.encoder = nn.Sequential(*encoder)

        decoder_dimensions = list(reversed(dimensions))
        decoder = []
        for index, (input_size, output_size) in enumerate(
            zip(decoder_dimensions, decoder_dimensions[1:])
        ):
            decoder.append(nn.Linear(input_size, output_size))
            if index < len(decoder_dimensions) - 2:
                decoder.append(nn.ReLU())
        self.decoder = nn.Sequential(*decoder)

    def forward(self, values):
        return self.decoder(self.encoder(values))


class SentinelDetector:
    """Point-at-a-time scalar detector with a robust branch and a PyTorch AE."""

    STATE_VERSION = 1
    TRAINING_WINDOW_LIMIT = 2048
    CALIBRATION_FRACTION = 0.2

    def __init__(
        self,
        config: Optional[SentinelConfig] = None,
        warmup_data_df=None,
    ):
        self.config = config or SentinelConfig()
        self._score_weight_lock = threading.Lock()
        if torch.get_num_threads() != self.config.torch_num_threads:
            torch.set_num_threads(self.config.torch_num_threads)
        self._model_lock = threading.Lock()
        self._normal_buffer_lock = threading.Lock()
        self._retrain_lock = threading.Lock()
        self._retrain_event = threading.Event()
        self._stop_event = threading.Event()
        self._retrain_finished = threading.Event()
        self._retrain_finished.set()
        self._retrain_thread: Optional[threading.Thread] = None
        self._retraining = False
        self.retrain_count = 0
        self._baseline_generation = 0
        self.normal_data_buffer: Deque[np.ndarray] = deque(maxlen=5000)
        self.value_buffer: Deque[float] = deque(maxlen=self.config.window_size)
        self.timestamp_buffer: Deque[str] = deque(maxlen=self.config.window_size)
        self.score_history: Deque[float] = deque(
            maxlen=self.config.score_history_size
        )
        self.calibration_stat_scores = np.empty(0, dtype=float)
        self.calibration_auto_scores = np.empty(0, dtype=float)
        self.calibration_seasonal_scores = np.empty(0, dtype=float)
        self._calibrated_threshold_weight: Optional[float] = None
        self.point_exceedance_buffer: Deque[bool] = deque(
            maxlen=self.config.window_size
        )
        self.drift_buffer: Deque[float] = deque(
            maxlen=self.config.adaptation_window
        )
        self.drift_timestamp_buffer: Deque[str] = deque(
            maxlen=self.config.adaptation_window
        )
        self.step_count = 0
        self.adaptation_count = 0
        self.last_adaptation = None
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.config.random_state)
            self.model = BottleneckAutoencoder(self.config.autoencoder_dims).cpu()
        self.model.eval()
        self.scaler_center = 0.0
        self.scaler_scale = 1.0
        self.stat_threshold = 4.0
        self.point_threshold = 0.0
        self.last_decision_details = {
            "statistical_score": 0.0,
            "autoencoder_score": 0.0,
            "point_deviation": 0.0,
            "point_threshold": self.point_threshold,
            "autoencoder_weight": self.config.autoencoder_weight,
            "statistical_weight": 1.0 - self.config.autoencoder_weight,
        }
        self.context_threshold = 4.5
        self.hourly_center = np.zeros(24, dtype=float)
        self.hourly_scale = np.ones(24, dtype=float)
        self.seasonal_threshold = 6.0
        self.seasonal_enabled = False
        self.auto_error_scale = 1e-6
        self.ema_score = 0.0
        self.threshold = 0.0
        self.calibrated_threshold = 0.0
        self.last_decision_threshold = 0.0
        self.is_fitted = False
        self.candidate_streak = 0
        self.last_features = {
            "rolling_mean": 0.0,
            "rolling_std": 0.0,
            "mad": 0.0,
            "autocorrelation": 0.0,
            "velocity": 0.0,
            "hour_sin": 0.0,
            "hour_cos": 1.0,
            "weekday_sin": 0.0,
            "weekday_cos": 1.0,
            "seasonal_z": 0.0,
        }

        if warmup_data_df is not None:
            values, timestamps = self._extract_training_data(warmup_data_df)
            self._fit(values, timestamps)
        if self.config.enable_background_retraining:
            self._start_retraining_worker()

    def set_autoencoder_weight(self, weight: float) -> None:
        """Set the live autoencoder share and recalibrate for that score blend."""
        numeric_weight = float(weight)
        if not math.isfinite(numeric_weight) or not 0.0 <= numeric_weight <= 1.0:
            raise ValueError("autoencoder weight must be between 0 and 1.")
        with self._score_weight_lock:
            self.config.autoencoder_weight = numeric_weight
        self._calibrated_threshold_weight = None
        if self.calibration_stat_scores.size:
            statistical_weight = 1.0 - numeric_weight
            calibrated_scores = np.maximum(
                statistical_weight * self.calibration_stat_scores
                + numeric_weight * self.calibration_auto_scores,
                self.calibration_seasonal_scores,
            )
            self.score_history.clear()
            self.score_history.extend(
                float(score)
                for score in calibrated_scores[-self.config.score_history_size :]
            )
            self.ema_score = (
                float(np.mean(self.score_history)) if self.score_history else 0.0
            )
            self.calibrated_threshold = 0.0
            self._refresh_threshold()
            self.last_decision_threshold = self.threshold

    @property
    def detection_mode(self) -> str:
        if self.config.autoencoder_weight == 0.0:
            return "statistics"
        if self.config.autoencoder_weight == 1.0:
            return "machine_learning"
        return "hybrid"

    def _fuse_scores(self, statistical_score: float, autoencoder_score: float) -> float:
        with self._score_weight_lock:
            autoencoder_weight = self.config.autoencoder_weight
        statistical_weight = 1.0 - autoencoder_weight
        return min(
            1.0,
            statistical_weight * statistical_score
            + autoencoder_weight * autoencoder_score,
        )

    @staticmethod
    def _format_timestamp(timestamp: Timestamp) -> str:
        if isinstance(timestamp, datetime):
            return timestamp.isoformat()
        return str(timestamp)

    @staticmethod
    def _parse_hour(timestamp: str) -> float:
        try:
            parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            return (
                parsed.hour
                + parsed.minute / 60.0
                + parsed.second / 3600.0
                + parsed.microsecond / 3_600_000_000.0
            )
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _hour_bucket(timestamp: str) -> Optional[int]:
        try:
            return datetime.fromisoformat(
                timestamp.replace("Z", "+00:00")
            ).hour
        except (AttributeError, TypeError, ValueError):
            return None

    @classmethod
    def _fit_hourly_profile(cls, values, timestamps):
        parsed_timestamps = []
        for timestamp in timestamps:
            try:
                parsed_timestamps.append(
                    datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                )
            except (AttributeError, TypeError, ValueError):
                continue
        if (
            len(parsed_timestamps) < 2
            or (max(parsed_timestamps) - min(parsed_timestamps)).total_seconds()
            < 2 * 24 * 60 * 60
        ):
            return np.zeros(24, dtype=float), np.ones(24, dtype=float), 6.0, False

        hour_indices = np.asarray(
            [
                -1 if (hour := cls._hour_bucket(timestamp)) is None else hour
                for timestamp in timestamps
            ],
            dtype=int,
        )
        valid = hour_indices >= 0
        centers = np.zeros(24, dtype=float)
        scales = np.ones(24, dtype=float)
        if np.count_nonzero(valid) < 24:
            return centers, scales, 6.0, False

        valid_hours = hour_indices[valid]
        valid_values = np.asarray(values, dtype=float)[valid]
        counts = np.bincount(valid_hours, minlength=24)
        available = np.flatnonzero(counts >= 3)
        if len(available) < 12:
            return centers, scales, 6.0, False

        for hour in available:
            bucket_values = valid_values[valid_hours == hour]
            centers[hour] = float(np.median(bucket_values))
        missing = np.flatnonzero(counts < 3)
        if len(missing):
            extended_hours = np.concatenate((available - 24, available, available + 24))
            extended_centers = np.tile(centers[available], 3)
            centers[missing] = np.interp(
                missing, extended_hours, extended_centers
            )

        residuals = np.abs(valid_values - centers[valid_hours])
        global_residual_scale = max(
            1.4826 * float(np.median(residuals)),
            float(np.std(residuals)) * 1e-3,
            1e-3,
        )
        floor = max(global_residual_scale * 0.1, 1e-3)
        for hour in range(24):
            bucket_residuals = np.abs(
                valid_values[valid_hours == hour] - centers[hour]
            )
            if bucket_residuals.size:
                scales[hour] = max(
                    1.4826 * float(np.median(bucket_residuals)),
                    floor,
                )
            else:
                scales[hour] = max(global_residual_scale, floor)

        residual_z = residuals / scales[valid_hours]
        seasonal_threshold = max(
            4.0,
            float(np.quantile(residual_z, 0.99)) * 1.5,
        )
        return centers, scales, seasonal_threshold, True

    def _seasonal_deviation(self, value, timestamp):
        hour = self._hour_bucket(timestamp)
        if not self.seasonal_enabled or hour is None:
            return 0.0
        return abs(float(value) - self.hourly_center[hour]) / max(
            self.hourly_scale[hour], 1e-6
        )

    def _seasonal_score(self, deviation):
        if not self.seasonal_enabled:
            return 0.0
        return min(1.0, deviation / (self.seasonal_threshold * 1.5))

    @classmethod
    def _extract_training_data(cls, data):
        if hasattr(data, "columns"):
            columns = list(data.columns)
            value_column = "value" if "value" in columns else None
            if value_column is None:
                candidates = [
                    name
                    for name in columns
                    if name.lower() not in {"timestamp", "time", "date", "label"}
                ]
                if not candidates:
                    raise ValueError("Warm-up data must contain a numeric value column.")
                value_column = candidates[0]
            values = np.asarray(data[value_column], dtype=float).reshape(-1)
            if "timestamp" in columns:
                timestamps = [cls._format_timestamp(value) for value in data["timestamp"]]
            else:
                timestamps = [str(index) for index in range(len(values))]
        elif isinstance(data, dict):
            if "value" not in data:
                raise ValueError("Warm-up data mapping must include a 'value' sequence.")
            values = np.asarray(data["value"], dtype=float).reshape(-1)
            raw_timestamps = data.get("timestamp", range(len(values)))
            timestamps = [cls._format_timestamp(value) for value in raw_timestamps]
            if len(timestamps) != len(values):
                raise ValueError("Warm-up timestamps and values must have equal lengths.")
        else:
            values = np.asarray(data, dtype=float).reshape(-1)
            timestamps = [str(index) for index in range(len(values))]

        valid = np.isfinite(values)
        values = values[valid]
        timestamps = [timestamp for timestamp, keep in zip(timestamps, valid) if keep]
        if len(values) < 2:
            raise ValueError("At least two finite warm-up observations are required.")
        return values, timestamps

    def _make_windows(self, normalized_values):
        count = len(normalized_values) - self.config.window_size + 1
        if count <= 0:
            raise ValueError(
                "Warm-up data must contain at least config.window_size observations."
            )
        windows = np.lib.stride_tricks.sliding_window_view(
            normalized_values, self.config.window_size
        )
        if len(windows) > self.TRAINING_WINDOW_LIMIT:
            selected = np.linspace(
                0, len(windows) - 1, self.TRAINING_WINDOW_LIMIT, dtype=int
            )
            windows = windows[selected]
        return np.asarray(windows, dtype=np.float32).copy()

    @staticmethod
    def _rolling_features(windows):
        means = np.mean(windows, axis=1)
        standard_deviations = np.std(windows, axis=1)
        medians = np.median(windows, axis=1)
        mads = np.median(np.abs(windows - medians[:, np.newaxis]), axis=1)
        centered = windows - means[:, np.newaxis]
        denominator = np.sum(centered[:, :-1] ** 2, axis=1)
        autocorrelation = np.divide(
            np.sum(centered[:, :-1] * centered[:, 1:], axis=1),
            denominator,
            out=np.zeros_like(denominator),
            where=denominator > 1e-12,
        )
        return np.column_stack(
            (means, standard_deviations, mads, autocorrelation)
        )

    def _fit(self, values: np.ndarray, timestamps: Sequence[str]):
        if len(values) < self.config.window_size:
            raise ValueError(
                "Warm-up data must contain at least config.window_size observations."
            )
        calibration_start = int(
            len(values) * (1.0 - self.CALIBRATION_FRACTION)
        )
        use_holdout = calibration_start >= self.config.window_size and (
            len(values) - calibration_start >= 1
        )
        baseline_values = values[:calibration_start] if use_holdout else values
        baseline_timestamps = (
            timestamps[:calibration_start] if use_holdout else timestamps
        )
        (
            self.hourly_center,
            self.hourly_scale,
            self.seasonal_threshold,
            self.seasonal_enabled,
        ) = self._fit_hourly_profile(baseline_values, baseline_timestamps)
        median = float(np.median(baseline_values))
        mad = float(np.median(np.abs(baseline_values - median)))
        self.scaler_center = median
        self.scaler_scale = max(
            1.4826 * mad, float(np.std(baseline_values)), 1e-6
        )
        self.point_threshold = float(
            np.quantile(
                np.abs(baseline_values - median),
                self.config.point_threshold_percentile / 100.0,
            )
        )
        self.point_exceedance_buffer.clear()
        self.point_exceedance_buffer.extend(
            abs(float(value) - median) > self.point_threshold
            for value in values[-(self.config.window_size - 1) :]
        )
        normalized = (values - self.scaler_center) / self.scaler_scale
        if use_holdout:
            training_normalized = normalized[:calibration_start]
            training_raw = values[:calibration_start]
            calibration_offset = calibration_start - self.config.window_size + 1
            calibration_normalized = normalized[calibration_offset:]
            calibration_raw_windows = np.lib.stride_tricks.sliding_window_view(
                values[calibration_offset:], self.config.window_size
            )
            calibration_timestamp_indices = np.arange(
                calibration_start, len(values)
            )
        else:
            training_normalized = normalized
            training_raw = values
            calibration_normalized = normalized
            calibration_raw_windows = np.lib.stride_tricks.sliding_window_view(
                values, self.config.window_size
            )
            calibration_timestamp_indices = np.arange(
                self.config.window_size - 1, len(values)
            )

        normalized_windows = np.lib.stride_tricks.sliding_window_view(
            training_normalized, self.config.window_size
        )
        raw_windows = np.lib.stride_tricks.sliding_window_view(
            training_raw, self.config.window_size
        )
        if len(normalized_windows) > self.TRAINING_WINDOW_LIMIT:
            selected = np.linspace(
                0,
                len(normalized_windows) - 1,
                self.TRAINING_WINDOW_LIMIT,
                dtype=int,
            )
            normalized_windows = normalized_windows[selected]
            raw_windows = raw_windows[selected]
        calibration_normalized_windows = np.lib.stride_tricks.sliding_window_view(
            calibration_normalized, self.config.window_size
        )
        if len(calibration_raw_windows) > self.TRAINING_WINDOW_LIMIT:
            calibration_indices = np.linspace(
                0,
                len(calibration_raw_windows) - 1,
                self.TRAINING_WINDOW_LIMIT,
                dtype=int,
            )
            calibration_raw_windows = calibration_raw_windows[calibration_indices]
            calibration_normalized_windows = calibration_normalized_windows[
                calibration_indices
            ]
            calibration_timestamp_indices = calibration_timestamp_indices[
                calibration_indices
            ]

        windows = np.asarray(normalized_windows, dtype=np.float32).copy()
        calibration_windows = np.asarray(
            calibration_normalized_windows, dtype=np.float32
        ).copy()
        train_features = self._rolling_features(raw_windows)
        self.feature_center = np.median(train_features, axis=0)
        feature_mad = np.median(
            np.abs(train_features - self.feature_center), axis=0
        )
        feature_range = np.ptp(train_features, axis=0)
        self.feature_scale = np.maximum(
            1.4826 * feature_mad, np.maximum(feature_range * 1e-3, 1e-6)
        )
        velocities = np.diff(training_raw)
        self.velocity_center = float(np.median(velocities))
        velocity_mad = float(np.median(np.abs(velocities - self.velocity_center)))
        self.velocity_scale = max(
            1.4826 * velocity_mad,
            float(np.std(velocities)),
            1e-6,
        )
        contextual_z = (
            np.abs(train_features[:, 3] - self.feature_center[3])
            / self.feature_scale[3]
        )
        self.context_threshold = max(
            4.5, float(np.quantile(contextual_z, 0.99)) * 1.5
        )
        training_windows = torch.from_numpy(windows)
        validation_windows = torch.from_numpy(calibration_windows)
        calibration_features = self._rolling_features(calibration_raw_windows)
        calibration_context_z = (
            np.abs(calibration_features[:, 3] - self.feature_center[3])
            / self.feature_scale[3]
        )
        calibration_seasonal_z = np.asarray(
            [
                self._seasonal_deviation(
                    float(values[int(index)]), timestamps[int(index)]
                )
                for index in calibration_timestamp_indices
            ],
            dtype=float,
        )
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.config.random_state)
            optimizer = torch.optim.Adam(
                self.model.parameters(), lr=self.config.learning_rate
            )
            self.model.train()
            batch_size = min(128, len(training_windows))
            best_validation_loss = float("inf")
            best_state = None
            epochs_without_improvement = 0
            self.training_epochs_completed = 0
            for _ in range(self.config.training_epochs):
                permutation = torch.randperm(len(training_windows))
                for start in range(0, len(training_windows), batch_size):
                    batch = training_windows[permutation[start : start + batch_size]]
                    optimizer.zero_grad(set_to_none=True)
                    loss = torch.mean((self.model(batch) - batch) ** 2)
                    loss.backward()
                    optimizer.step()
                self.training_epochs_completed += 1

                if use_holdout:
                    self.model.eval()
                    with torch.inference_mode():
                        validation_loss = float(
                            torch.mean(
                                (
                                    self.model(validation_windows)
                                    - validation_windows
                                )
                                ** 2
                            ).item()
                        )
                    if validation_loss < best_validation_loss:
                        best_validation_loss = validation_loss
                        best_state = {
                            name: tensor.detach().clone()
                            for name, tensor in self.model.state_dict().items()
                        }
                        epochs_without_improvement = 0
                    else:
                        epochs_without_improvement += 1
                    self.model.train()
                    if (
                        epochs_without_improvement
                        >= self.config.training_patience
                    ):
                        break

            if best_state is not None:
                self.model.load_state_dict(best_state)

        self.model.eval()
        with torch.inference_mode():
            reconstruction = self.model(torch.from_numpy(calibration_windows))
            errors = torch.mean(
                (reconstruction - torch.from_numpy(calibration_windows)) ** 2,
                dim=1,
            ).numpy()

        self.auto_error_scale = max(
            float(np.quantile(errors, 0.99)) * 6.0,
            float(np.median(errors)) * 6.0,
            1e-6,
        )
        global_point_z = np.abs(
            0.6745
            * (training_raw - median)
            / max(self.scaler_scale / 1.4826, 1e-6)
        )
        training_feature_z = np.max(
            np.abs(train_features[:, :3] - self.feature_center[:3])
            / self.feature_scale[:3],
            axis=1,
        )
        self.stat_threshold = max(
            6.0,
            float(np.quantile(global_point_z, 0.99)) * 1.5,
            float(np.quantile(training_feature_z, 0.99)) * 1.5,
        )
        scores = []
        calibration_stat_scores = []
        calibration_auto_scores = []
        calibration_seasonal_scores = []
        for index, error in enumerate(errors):
            window_values = calibration_raw_windows[index]
            historical_values = window_values[:-1]
            center = float(np.median(historical_values))
            window_mad = float(np.median(np.abs(historical_values - center)))
            modified_z = abs(
                0.6745 * (float(window_values[-1]) - center)
            ) / max(window_mad, self.scaler_scale / 1.4826, 1e-6)
            global_z = abs(
                0.6745 * (float(window_values[-1]) - self.scaler_center)
            ) / max(self.scaler_scale / 1.4826, 1e-6)
            rolling_z = float(
                np.max(
                    np.abs(
                        calibration_features[index, :3] - self.feature_center[:3]
                    )
                    / self.feature_scale[:3]
                )
            )
            temporal_z = float(calibration_context_z[index])
            stat_score = min(
                1.0,
                max(
                    modified_z / self.stat_threshold,
                    global_z / self.stat_threshold,
                    rolling_z / self.stat_threshold,
                    temporal_z / self.context_threshold,
                    float(calibration_seasonal_z[index])
                    / self.seasonal_threshold,
                ),
            )
            auto_score = min(1.0, float(error) / self.auto_error_scale)
            seasonal_score = self._seasonal_score(
                float(calibration_seasonal_z[index])
            )
            calibration_stat_scores.append(stat_score)
            calibration_auto_scores.append(auto_score)
            calibration_seasonal_scores.append(seasonal_score)
            scores.append(max(self._fuse_scores(stat_score, auto_score), seasonal_score))

        self.calibration_stat_scores = np.asarray(calibration_stat_scores, dtype=float)
        self.calibration_auto_scores = np.asarray(calibration_auto_scores, dtype=float)
        self.calibration_seasonal_scores = np.asarray(
            calibration_seasonal_scores, dtype=float
        )
        self._calibrated_threshold_weight = None
        self.score_history.clear()
        for score in scores[-self.config.score_history_size :]:
            self.score_history.append(float(score))
        self.ema_score = float(np.mean(self.score_history)) if self.score_history else 0.0
        self.candidate_streak = 0
        self._refresh_threshold()
        self.calibrated_threshold = self.threshold
        self.value_buffer.clear()
        self.timestamp_buffer.clear()
        for value, timestamp in zip(
            values[-self.config.window_size :],
            timestamps[-self.config.window_size :],
        ):
            self.value_buffer.append(float(value))
            self.timestamp_buffer.append(timestamp)
        self.is_fitted = True

    def _refresh_threshold(self):
        if not self.score_history:
            self.threshold = 0.0
            return
        if self.calibration_stat_scores.size:
            with self._score_weight_lock:
                autoencoder_weight = self.config.autoencoder_weight
            if self._calibrated_threshold_weight != autoencoder_weight:
                calibrated_scores = np.maximum(
                    (1.0 - autoencoder_weight) * self.calibration_stat_scores
                    + autoencoder_weight * self.calibration_auto_scores,
                    self.calibration_seasonal_scores,
                )
                self.calibrated_threshold = float(
                    np.percentile(
                        calibrated_scores,
                        self.config.threshold_percentile,
                    )
                )
                self._calibrated_threshold_weight = autoencoder_weight
        scores = np.asarray(self.score_history, dtype=float)
        percentile = float(np.percentile(scores, self.config.threshold_percentile))
        ema_adjustment = self.config.ema_alpha * self.ema_score
        adaptive_threshold = min(1.0, percentile + ema_adjustment)
        self.threshold = max(
            self.config.threshold_floor,
            self.calibrated_threshold,
            adaptive_threshold,
        )

    def _start_retraining_worker(self):
        self._retrain_thread = threading.Thread(
            target=self._retraining_worker,
            name="SentinelAutoencoderRetrainer",
            daemon=True,
        )
        self._retrain_thread.start()

    def _retraining_worker(self):
        while not self._stop_event.is_set():
            if not self._retrain_event.wait(timeout=0.2):
                continue
            self._retrain_event.clear()
            if self._stop_event.is_set():
                break

            with self._normal_buffer_lock:
                window_count = len(self.normal_data_buffer)
                if window_count < max(32, self.config.window_size):
                    continue
                selected_indices = np.linspace(
                    0, window_count - 1, min(64, window_count), dtype=int
                )
                windows = [
                    self.normal_data_buffer[index].copy()
                    for index in selected_indices
                ]
            if not windows:
                continue

            with self._retrain_lock:
                self._retraining = True
                self._retrain_finished.clear()
            try:
                raw_windows = np.stack(windows)
                with self._model_lock:
                    baseline_generation = self._baseline_generation
                    scaler_center = self.scaler_center
                    scaler_scale = self.scaler_scale
                    current_state = {
                        name: tensor.detach().clone()
                        for name, tensor in self.model.state_dict().items()
                    }
                normalized_windows = (
                    (raw_windows - scaler_center) / scaler_scale
                ).astype(np.float32, copy=False)
                training_data = torch.from_numpy(normalized_windows.copy())
                shadow_model = BottleneckAutoencoder(
                    self.config.autoencoder_dims
                ).cpu()
                shadow_model.load_state_dict(current_state)

                optimizer = torch.optim.Adam(
                    shadow_model.parameters(), lr=self.config.learning_rate
                )
                generator = torch.Generator().manual_seed(
                    self.config.random_state + self.retrain_count + self.step_count
                )
                shadow_model.train()
                batch_size = len(training_data)
                for _ in range(2):
                    permutation = torch.randperm(
                        len(training_data), generator=generator
                    )
                    for start in range(0, len(training_data), batch_size):
                        batch = training_data[
                            permutation[start : start + batch_size]
                        ]
                        optimizer.zero_grad(set_to_none=True)
                        loss = torch.mean((shadow_model(batch) - batch) ** 2)
                        loss.backward()
                        optimizer.step()

                shadow_model.eval()
                with torch.inference_mode():
                    reconstruction = shadow_model(training_data)
                    errors = torch.mean(
                        (reconstruction - training_data) ** 2, dim=1
                    ).numpy()
                new_auto_error_scale = max(
                    float(np.quantile(errors, 0.99)) * 6.0,
                    float(np.median(errors)) * 6.0,
                    1e-6,
                )

                with self._model_lock:
                    if baseline_generation != self._baseline_generation:
                        logger.info(
                            "Discarded stale background model after baseline replacement."
                        )
                        continue
                    self.model.load_state_dict(shadow_model.state_dict())
                    self.model.eval()
                    self.auto_error_scale = new_auto_error_scale
                    self.retrain_count += 1
                logger.info(
                    "Background autoencoder retraining completed (version %d, %d windows).",
                    self.retrain_count,
                    len(training_data),
                )
            except Exception:
                logger.exception("Background autoencoder retraining failed.")
            finally:
                with self._retrain_lock:
                    self._retraining = False
                    self._retrain_finished.set()

    def _schedule_retraining(self):
        if (
            self.config.enable_background_retraining
            and self.step_count
            and self.step_count % self.config.retrain_interval == 0
        ):
            self._retrain_event.set()

    def stop(self) -> None:
        """Stop and join the optional background retraining worker."""
        self._stop_event.set()
        self._retrain_event.set()
        if self._retrain_thread is not None:
            self._retrain_thread.join()

    def _try_adapt_to_new_normal(self, timestamp):
        # A timestamp-conditioned profile distinguishes a recurring normal
        # cycle from a sustained contextual anomaly. Re-baselining from that
        # stream alone could absorb an entire labeled event as "new normal".
        # Use update_normal_baseline() for reviewed seasonal baseline changes.
        if self.seasonal_enabled:
            return False
        if len(self.drift_buffer) < self.config.adaptation_window:
            return False
        if self.step_count % self.config.window_size:
            return False

        candidate = np.asarray(self.drift_buffer, dtype=float)
        candidate_timestamps = list(self.drift_timestamp_buffer)
        half = len(candidate) // 2
        first_center = float(np.median(candidate[:half]))
        second_center = float(np.median(candidate[half:]))
        center = float(np.median(candidate))
        mad = float(np.median(np.abs(candidate - center)))
        candidate_scale = max(1.4826 * mad, float(np.std(candidate)), 1e-6)
        old_scale = max(self.scaler_scale, 1e-6)
        variance_ratio = (candidate_scale / old_scale) ** 2
        stable_limit = max(candidate_scale * 1.5, old_scale * 0.5)
        distribution_shift = (
            abs(center - self.scaler_center)
            >= self.config.drift_sensitivity * old_scale
            or variance_ratio <= self.config.variance_change_ratio
        )
        stable_candidate = (
            abs(first_center - second_center) <= stable_limit
            and candidate_scale <= old_scale * 5.0
        )
        if not distribution_shift or not stable_candidate:
            return False

        windows = np.lib.stride_tricks.sliding_window_view(
            candidate, self.config.window_size
        )
        window_indices = np.arange(len(windows))
        if len(windows) > 8:
            window_indices = np.linspace(0, len(windows) - 1, 8, dtype=int)
            indices = window_indices
            windows = windows[indices]
        normalized_windows = (
            (windows - center) / candidate_scale
        ).astype(np.float32, copy=False)
        features = self._rolling_features(windows)

        with self._model_lock, torch.inference_mode():
            tensor = torch.from_numpy(normalized_windows)
            reconstruction = self.model(tensor)
            errors = torch.mean((reconstruction - tensor) ** 2, dim=1).numpy()

        feature_center = np.median(features, axis=0)
        feature_mad = np.median(np.abs(features - feature_center), axis=0)
        feature_scale = np.maximum(
            1.4826 * feature_mad,
            np.maximum(np.ptp(features, axis=0) * 1e-3, 1e-6),
        )
        contextual_z = (
            np.abs(features[:, 3] - feature_center[3]) / feature_scale[3]
        )
        rolling_z = np.max(
            np.abs(features[:, :3] - feature_center[:3]) / feature_scale[:3],
            axis=1,
        )
        stat_threshold = max(
            6.0,
            float(np.quantile(rolling_z, 0.99)) * 1.5,
            float(np.quantile(contextual_z, 0.99)) * 1.5,
        )

        velocities = np.diff(candidate)
        velocity_center = float(np.median(velocities))
        velocity_mad = float(np.median(np.abs(velocities - velocity_center)))
        velocity_scale = max(
            1.4826 * velocity_mad,
            float(np.std(velocities)),
            1e-6,
        )
        auto_error_scale = max(
            float(np.quantile(errors, 0.99)) * 6.0,
            float(np.median(errors)) * 6.0,
            1e-6,
        )
        (
            hourly_center,
            hourly_scale,
            seasonal_threshold,
            seasonal_enabled,
        ) = self._fit_hourly_profile(candidate, candidate_timestamps)
        with self._model_lock:
            self.scaler_center = center
            self.scaler_scale = candidate_scale
            self.point_threshold = float(
                np.quantile(
                    np.abs(candidate - center),
                    self.config.point_threshold_percentile / 100.0,
                )
            )
            self.point_exceedance_buffer.clear()
            self.point_exceedance_buffer.extend(
                abs(float(value) - center) > self.point_threshold
                for value in candidate[-(self.config.window_size - 1) :]
            )
            self.feature_center = feature_center
            self.feature_scale = feature_scale
            self.stat_threshold = stat_threshold
            self.context_threshold = max(
                4.5, float(np.quantile(contextual_z, 0.99)) * 1.5
            )
            self.velocity_center = velocity_center
            self.velocity_scale = velocity_scale
            self.auto_error_scale = auto_error_scale
            self.hourly_center = hourly_center
            self.hourly_scale = hourly_scale
            self.seasonal_threshold = seasonal_threshold
            self.seasonal_enabled = seasonal_enabled
            self._baseline_generation += 1
        with self._normal_buffer_lock:
            self.normal_data_buffer.clear()

        scores = []
        calibration_stat_scores = []
        calibration_auto_scores = []
        calibration_seasonal_scores = []
        for index, (window, error) in enumerate(zip(windows, errors)):
            point = float(window[-1])
            point_median = float(np.median(window))
            point_mad = float(np.median(np.abs(window - point_median)))
            modified_z = abs(0.6745 * (point - point_median)) / max(
                point_mad,
                candidate_scale / 1.4826,
                1e-6,
            )
            global_z = abs(0.6745 * (point - center)) / max(candidate_scale / 1.4826, 1e-6)
            stat_score = min(
                1.0,
                max(
                    modified_z / stat_threshold,
                    global_z / stat_threshold,
                    float(rolling_z[index]) / stat_threshold,
                    float(contextual_z[index]) / self.context_threshold,
                    self._seasonal_deviation(
                        float(window[-1]),
                        candidate_timestamps[
                            int(window_indices[index]) + self.config.window_size - 1
                        ],
                    )
                    / self.seasonal_threshold,
                ),
            )
            auto_score = min(1.0, float(error) / self.auto_error_scale)
            seasonal_z = self._seasonal_deviation(point, candidate_timestamps[
                int(window_indices[index]) + self.config.window_size - 1
            ])
            seasonal_score = self._seasonal_score(seasonal_z)
            calibration_stat_scores.append(stat_score)
            calibration_auto_scores.append(auto_score)
            calibration_seasonal_scores.append(seasonal_score)
            scores.append(
                max(
                    self._fuse_scores(stat_score, auto_score),
                    seasonal_score,
                )
            )

        self.calibration_stat_scores = np.asarray(calibration_stat_scores, dtype=float)
        self.calibration_auto_scores = np.asarray(calibration_auto_scores, dtype=float)
        self.calibration_seasonal_scores = np.asarray(
            calibration_seasonal_scores, dtype=float
        )
        self._calibrated_threshold_weight = None
        self.score_history.clear()
        self.score_history.extend(scores[-self.config.score_history_size :])
        self.ema_score = float(np.mean(self.score_history)) if self.score_history else 0.0
        self.calibrated_threshold = 0.0
        self._refresh_threshold()
        self.calibrated_threshold = self.threshold
        self.value_buffer.clear()
        self.timestamp_buffer.clear()
        for value, stamp in zip(
            candidate[-self.config.window_size :],
            candidate_timestamps[-self.config.window_size :],
        ):
            self.value_buffer.append(float(value))
            self.timestamp_buffer.append(stamp)
        self.drift_buffer.clear()
        self.drift_timestamp_buffer.clear()
        self.candidate_streak = 0
        self.adaptation_count += 1
        self.last_adaptation = self._format_timestamp(timestamp)
        logger.info(
            "Adapted Sentinel baseline to sustained new normal: center=%.6f scale=%.6f",
            self.scaler_center,
            self.scaler_scale,
        )
        return True

    def _safe_result(self, timestamp, value, evidence):
        try:
            safe_value = float(value)
            if not math.isfinite(safe_value):
                safe_value = 0.0
        except (TypeError, ValueError, OverflowError):
            safe_value = 0.0
        return AnomalyResult(
            timestamp=self._format_timestamp(timestamp),
            value=safe_value,
            anomaly_score=0.0,
            is_anomalous=False,
            evidence=evidence,
        )

    def _compute_features(self, values, timestamp):
        array = np.asarray(values, dtype=float)
        mean = float(np.mean(array))
        standard_deviation = float(np.std(array))
        median = float(np.median(array))
        mad = float(np.median(np.abs(array - median)))
        hour = self._parse_hour(timestamp)
        angle = 2.0 * math.pi * hour / 24.0
        try:
            parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            weekday_angle = 2.0 * math.pi * parsed.weekday() / 7.0
        except (TypeError, ValueError):
            weekday_angle = 0.0
        return {
            "rolling_mean": mean,
            "rolling_std": standard_deviation,
            "mad": mad,
            "autocorrelation": float(
                np.dot(array[:-1] - mean, array[1:] - mean)
                / max(float(np.sum((array[:-1] - mean) ** 2)), 1e-12)
            ),
            "velocity": float(array[-1] - array[-2]),
            "hour_sin": math.sin(angle),
            "hour_cos": math.cos(angle),
            "weekday_sin": math.sin(weekday_angle),
            "weekday_cos": math.cos(weekday_angle),
            "seasonal_z": self._seasonal_deviation(float(array[-1]), timestamp),
        }

    def _stat_score(self, current_value, window, reference_window=None):
        reference = (
            np.asarray(window[:-1], dtype=float)
            if reference_window is None
            else np.asarray(reference_window, dtype=float)
        )
        median = float(np.median(reference))
        mad = float(np.median(np.abs(reference - median)))
        modified_z = abs(0.6745 * (current_value - median)) / max(
            mad,
            self.scaler_scale / 1.4826,
            1e-6,
        )
        global_z = abs(
            0.6745 * (current_value - self.scaler_center)
        ) / max(self.scaler_scale / 1.4826, 1e-6)
        velocity = self.last_features["velocity"]
        velocity_z = abs(velocity - self.velocity_center) / max(
            self.velocity_scale, 1e-6
        )
        features = np.asarray(
            [
                self.last_features["rolling_mean"],
                self.last_features["rolling_std"],
                self.last_features["mad"],
                self.last_features["autocorrelation"],
            ]
        )
        rolling_z = float(
            np.max(
                np.abs(features[:3] - self.feature_center[:3])
                / self.feature_scale[:3]
            )
        )
        contextual_z = float(
            abs(features[3] - self.feature_center[3]) / self.feature_scale[3]
        )
        point_deviation = max(modified_z, global_z)
        score = min(
            1.0,
            max(
                point_deviation / self.stat_threshold,
                velocity_z / self.stat_threshold,
                rolling_z / self.stat_threshold,
                contextual_z / self.context_threshold,
                self.last_features["seasonal_z"] / self.seasonal_threshold,
            ),
        )
        return score, point_deviation, contextual_z

    def _auto_score(self, window):
        normalized = (window - self.scaler_center) / self.scaler_scale
        tensor = torch.from_numpy(normalized.astype(np.float32, copy=False)).unsqueeze(0)
        with self._model_lock, torch.inference_mode():
            self.model.eval()
            reconstruction = self.model(tensor)
            error = float(torch.mean((reconstruction - tensor) ** 2).item())
        return min(1.0, error / self.auto_error_scale), error

    def update_normal_baseline(self, normal_data_df):
        """Retrain on explicitly supplied, reviewed normal data.

        Fit into a temporary detector first, so a bad dataset cannot partially
        replace the active production baseline. Run this outside the hot stream
        path; neural fitting is intentionally not performed in process_step().
        """
        values, timestamps = self._extract_training_data(normal_data_df)
        replacement_config = asdict(self.config)
        replacement_config["enable_background_retraining"] = False
        config = SentinelConfig(**replacement_config)
        replacement = type(self)(config)
        replacement._fit(values, timestamps)
        with self._model_lock:
            self.model.load_state_dict(replacement.model.state_dict())
            self.model.eval()
            self._baseline_generation += 1
            self.scaler_center = replacement.scaler_center
            self.scaler_scale = replacement.scaler_scale
            self.stat_threshold = replacement.stat_threshold
            self.point_threshold = replacement.point_threshold
            self.calibration_stat_scores = replacement.calibration_stat_scores.copy()
            self.calibration_auto_scores = replacement.calibration_auto_scores.copy()
            self.calibration_seasonal_scores = (
                replacement.calibration_seasonal_scores.copy()
            )
            self._calibrated_threshold_weight = None
            self.context_threshold = replacement.context_threshold
            self.auto_error_scale = replacement.auto_error_scale
            self.velocity_center = replacement.velocity_center
            self.velocity_scale = replacement.velocity_scale
            self.feature_center = replacement.feature_center
            self.feature_scale = replacement.feature_scale
            self.hourly_center = replacement.hourly_center.copy()
            self.hourly_scale = replacement.hourly_scale.copy()
            self.seasonal_threshold = replacement.seasonal_threshold
            self.seasonal_enabled = replacement.seasonal_enabled
            self.score_history.clear()
            self.score_history.extend(replacement.score_history)
            self.ema_score = replacement.ema_score
            self.threshold = replacement.threshold
            self.calibrated_threshold = replacement.calibrated_threshold
            self.value_buffer.clear()
            self.value_buffer.extend(replacement.value_buffer)
            self.timestamp_buffer.clear()
            self.timestamp_buffer.extend(replacement.timestamp_buffer)
            self.point_exceedance_buffer.clear()
            self.point_exceedance_buffer.extend(
                replacement.point_exceedance_buffer
            )
            self.drift_buffer.clear()
            self.drift_timestamp_buffer.clear()
            self.candidate_streak = 0
            self.is_fitted = True
            self.last_features = dict(replacement.last_features)
            self.adaptation_count += 1
            self.last_adaptation = datetime.now().isoformat()
        with self._normal_buffer_lock:
            self.normal_data_buffer.clear()

    def set_normal_baseline(self, normal_data_df):
        """Alias for updating the baseline from an explicitly approved dataset."""
        self.update_normal_baseline(normal_data_df)

    def process_step(self, timestamp: Timestamp, value: float) -> AnomalyResult:
        """Process one sample; invalid input is logged and returns a safe result."""
        try:
            numeric_value = float(value)
            if not math.isfinite(numeric_value):
                raise ValueError("value must be finite.")
            timestamp_text = self._format_timestamp(timestamp)
            if not self.is_fitted:
                self.value_buffer.append(numeric_value)
                self.timestamp_buffer.append(timestamp_text)
                if len(self.value_buffer) < self.config.window_size:
                    return AnomalyResult(
                        timestamp_text,
                        numeric_value,
                        0.0,
                        False,
                        "Warming up buffer",
                    )
                self._fit(
                    np.asarray(self.value_buffer, dtype=float),
                    list(self.timestamp_buffer),
                )
                return AnomalyResult(
                    timestamp_text,
                    numeric_value,
                    0.0,
                    False,
                    "Warming up baseline",
                )

            self.step_count += 1
            self.drift_buffer.append(numeric_value)
            self.drift_timestamp_buffer.append(timestamp_text)
            previous_window = np.asarray(self.value_buffer, dtype=float)
            window = np.asarray(
                list(previous_window[1:]) + [numeric_value], dtype=float
            )
            if len(window) < self.config.window_size:
                self.value_buffer.append(numeric_value)
                self.timestamp_buffer.append(timestamp_text)
                return AnomalyResult(
                    timestamp_text, numeric_value, 0.0, False, "Warming up buffer"
                )

            self.last_features = self._compute_features(window, timestamp_text)
            stat_score, deviation, _ = self._stat_score(
                numeric_value, window, previous_window
            )
            auto_score, reconstruction_error = self._auto_score(window)
            seasonal_alarm = (
                self.last_features["seasonal_z"] >= self.seasonal_threshold
            )
            final_score = max(
                self._fuse_scores(stat_score, auto_score),
                self._seasonal_score(self.last_features["seasonal_z"]),
                1.0 if seasonal_alarm else 0.0,
            )

            self._refresh_threshold()
            self.last_decision_threshold = self.threshold
            is_candidate = final_score >= self.last_decision_threshold
            baseline_suppressed = (
                is_candidate and numeric_value <= self.config.baseline_tolerance
            )
            point_deviation = abs(numeric_value - self.scaler_center)
            self.point_exceedance_buffer.append(
                point_deviation > self.point_threshold
            )
            point_exceedance_count = sum(self.point_exceedance_buffer)
            with self._score_weight_lock:
                autoencoder_weight = self.config.autoencoder_weight
            point_trigger = autoencoder_weight == 1.0 or seasonal_alarm or (
                point_deviation > 2.0 * self.point_threshold
                or (
                    point_deviation > self.point_threshold
                    and point_exceedance_count
                    >= min(
                        self.config.point_cluster_min_count,
                        self.config.window_size,
                    )
                )
            )
            if baseline_suppressed:
                logger.debug(
                    "suppressed_baseline_return timestamp=%s value=%.6f score=%.6f",
                    timestamp_text,
                    numeric_value,
                    final_score,
                )
            self.candidate_streak = self.candidate_streak + 1 if is_candidate else 0
            is_anomalous = is_candidate and point_trigger and not baseline_suppressed
            adapted = (
                False
                if seasonal_alarm
                else self._try_adapt_to_new_normal(timestamp_text)
            )
            if is_anomalous:
                if self.last_features["seasonal_z"] >= self.seasonal_threshold:
                    evidence = (
                        "Seasonal Context Anomaly: Value deviated by "
                        f"{self.last_features['seasonal_z']:.2f} seasonal robust "
                        f"deviations; ML reconstruction MSE={reconstruction_error:.5f}."
                    )
                elif point_deviation > self.point_threshold:
                    evidence = (
                        "Point Spike Anomaly: "
                        f"Value deviated by {deviation:.2f} robust standard deviations; "
                        f"global deviation={point_deviation:.5f} exceeds calibrated "
                        f"point threshold={self.point_threshold:.5f}; "
                        f"ML reconstruction MSE={reconstruction_error:.5f}."
                    )
                else:
                    evidence = (
                        "Contextual Pattern Anomaly: "
                        f"ML reconstruction MSE={reconstruction_error:.5f}, "
                        f"statistical score={stat_score:.3f}, "
                        f"score={final_score:.3f} >= threshold="
                        f"{self.last_decision_threshold:.3f}."
                    )
                if adapted:
                    evidence += "; adapted baseline to sustained new normal"
                median = float(np.median(window))
                mad = float(np.median(np.abs(window - median)))
                clip_distance = max(
                    self.stat_threshold * max(mad, 1e-6) / 0.6745,
                    1e-6,
                )
                buffered_value = float(
                    np.clip(
                        numeric_value,
                        median - clip_distance,
                        median + clip_distance,
                    )
                )
                self.value_buffer.append(buffered_value)
                self.timestamp_buffer.append(timestamp_text)
            elif baseline_suppressed:
                evidence = "Baseline return suppressed (suppressed_baseline_return)."
                self.value_buffer.append(numeric_value)
                self.timestamp_buffer.append(timestamp_text)
            else:
                evidence = (
                    "Contextual score exceeded threshold but point magnitude "
                    "remained below the calibrated point threshold."
                    if is_candidate
                    else "Within adaptive baseline."
                )
                if adapted:
                    evidence = "Adapted baseline to sustained lower-variance normal regime."
                if final_score < self.threshold * 0.85:
                    self.value_buffer.append(numeric_value)
                    self.timestamp_buffer.append(timestamp_text)
                else:
                    median = float(np.median(window))
                    mad = float(np.median(np.abs(window - median)))
                    clip_distance = max(
                        self.stat_threshold * max(mad, 1e-6) / 0.6745,
                        1e-6,
                    )
                    self.value_buffer.append(
                        float(
                            np.clip(
                                numeric_value,
                                median - clip_distance,
                                median + clip_distance,
                            )
                        )
                    )
                    self.timestamp_buffer.append(timestamp_text)
                if not is_candidate:
                    self.score_history.append(final_score)
                    self.ema_score = (
                        (1.0 - self.config.ema_alpha) * self.ema_score
                        + self.config.ema_alpha * final_score
                    )
                    self._refresh_threshold()

            self.last_decision_details = {
                "statistical_score": round(float(stat_score), 6),
                "autoencoder_score": round(float(auto_score), 6),
                "reconstruction_mse": round(float(reconstruction_error), 8),
                "anomaly_score": round(float(final_score), 6),
                "decision_threshold": round(float(self.last_decision_threshold), 6),
                "threshold_exceeded": bool(is_candidate),
                "point_deviation": round(float(point_deviation), 8),
                "point_threshold": round(float(self.point_threshold), 8),
                "statistical_weight": round(1.0 - autoencoder_weight, 4),
                "autoencoder_weight": round(autoencoder_weight, 4),
                "mode": self.detection_mode,
                "point_trigger": bool(point_trigger),
                "baseline_suppressed": bool(baseline_suppressed),
                "is_anomalous": bool(is_anomalous),
                "seasonal_deviation": round(
                    float(self.last_features["seasonal_z"]), 6
                ),
                "evidence": evidence,
            }

            if not is_anomalous and final_score < 0.2:
                with self._normal_buffer_lock:
                    self.normal_data_buffer.append(window.copy())
            self._schedule_retraining()

            return AnomalyResult(
                timestamp=timestamp_text,
                value=numeric_value,
                anomaly_score=float(final_score),
                is_anomalous=is_anomalous,
                evidence=evidence,
            )
        except Exception as error:
            logger.exception("Sentinel inference failed for timestamp %r", timestamp)
            return self._safe_result(timestamp, value, f"Inference error: {error}")

    def save_state(self, filepath: Union[str, os.PathLike]) -> None:
        """Persist the model and trusted, pickled stream state to a torch file."""
        with self._normal_buffer_lock:
            normal_windows = [window.copy() for window in self.normal_data_buffer]
        with self._model_lock:
            model_state = {
                name: tensor.detach().clone()
                for name, tensor in self.model.state_dict().items()
            }
        stream_state = {
            "version": self.STATE_VERSION,
            "config": asdict(self.config),
            "value_buffer": list(self.value_buffer),
            "timestamp_buffer": list(self.timestamp_buffer),
            "score_history": list(self.score_history),
            "calibration_stat_scores": self.calibration_stat_scores,
            "calibration_auto_scores": self.calibration_auto_scores,
            "calibration_seasonal_scores": self.calibration_seasonal_scores,
            "point_exceedance_buffer": list(self.point_exceedance_buffer),
            "scaler_center": self.scaler_center,
            "scaler_scale": self.scaler_scale,
            "stat_threshold": self.stat_threshold,
            "point_threshold": self.point_threshold,
            "velocity_center": getattr(self, "velocity_center", 0.0),
            "velocity_scale": getattr(self, "velocity_scale", 1.0),
            "auto_error_scale": self.auto_error_scale,
            "ema_score": self.ema_score,
            "threshold": self.threshold,
            "last_decision_threshold": self.last_decision_threshold,
            "calibrated_threshold": self.calibrated_threshold,
            "is_fitted": self.is_fitted,
            "last_features": self.last_features,
            "last_decision_details": self.last_decision_details,
            "feature_center": getattr(self, "feature_center", None),
            "feature_scale": getattr(self, "feature_scale", None),
            "context_threshold": self.context_threshold,
            "hourly_center": self.hourly_center,
            "hourly_scale": self.hourly_scale,
            "seasonal_threshold": self.seasonal_threshold,
            "seasonal_enabled": self.seasonal_enabled,
            "candidate_streak": self.candidate_streak,
            "drift_buffer": list(self.drift_buffer),
            "drift_timestamp_buffer": list(self.drift_timestamp_buffer),
            "step_count": self.step_count,
            "adaptation_count": self.adaptation_count,
            "last_adaptation": self.last_adaptation,
            "normal_data_buffer": normal_windows,
            "retrain_count": self.retrain_count,
        }
        torch.save(
            {
                "model_state_dict": model_state,
                "stream_state": pickle.dumps(stream_state, protocol=pickle.HIGHEST_PROTOCOL),
            },
            filepath,
        )

    @classmethod
    def load_state(cls, filepath: Union[str, os.PathLike]) -> "SentinelDetector":
        """Load a state file produced by save_state; only load trusted files."""
        try:
            payload = torch.load(filepath, map_location="cpu", weights_only=False)
        except TypeError:
            payload = torch.load(filepath, map_location="cpu")
        state = pickle.loads(payload["stream_state"])
        if state.get("version") != cls.STATE_VERSION:
            raise ValueError("Unsupported Sentinel state file version.")
        config = SentinelConfig(**state["config"])
        detector = cls(config)
        with detector._model_lock:
            detector.model.load_state_dict(payload["model_state_dict"])
            detector.model.eval()
        detector.value_buffer.extend(state["value_buffer"])
        detector.timestamp_buffer.extend(state["timestamp_buffer"])
        detector.score_history.extend(state["score_history"])
        detector.calibration_stat_scores = np.asarray(
            state.get("calibration_stat_scores", []), dtype=float
        )
        detector.calibration_auto_scores = np.asarray(
            state.get("calibration_auto_scores", []), dtype=float
        )
        detector.calibration_seasonal_scores = np.asarray(
            state.get("calibration_seasonal_scores", []), dtype=float
        )
        detector._calibrated_threshold_weight = None
        detector.point_exceedance_buffer.extend(
            state.get("point_exceedance_buffer", [])
        )
        detector.scaler_center = state["scaler_center"]
        detector.scaler_scale = state["scaler_scale"]
        detector.stat_threshold = state["stat_threshold"]
        detector.point_threshold = state.get("point_threshold", 0.0)
        detector.velocity_center = state.get("velocity_center", 0.0)
        detector.velocity_scale = state.get("velocity_scale", 1.0)
        detector.auto_error_scale = state["auto_error_scale"]
        detector.ema_score = state["ema_score"]
        detector.threshold = state["threshold"]
        detector.last_decision_threshold = state.get(
            "last_decision_threshold", detector.threshold
        )
        detector.calibrated_threshold = state.get(
            "calibrated_threshold", detector.threshold
        )
        detector.is_fitted = state["is_fitted"]
        detector.last_features = state["last_features"]
        detector.last_decision_details = state.get(
            "last_decision_details", detector.last_decision_details
        )
        if state["feature_center"] is not None:
            detector.feature_center = state["feature_center"]
            detector.feature_scale = state["feature_scale"]
        detector.context_threshold = state.get("context_threshold", 4.5)
        detector.hourly_center = np.asarray(
            state.get("hourly_center", np.zeros(24)), dtype=float
        )
        detector.hourly_scale = np.asarray(
            state.get("hourly_scale", np.ones(24)), dtype=float
        )
        detector.seasonal_threshold = state.get("seasonal_threshold", 6.0)
        detector.seasonal_enabled = state.get("seasonal_enabled", False)
        detector.candidate_streak = state.get("candidate_streak", 0)
        detector.drift_buffer.extend(state.get("drift_buffer", []))
        detector.drift_timestamp_buffer.extend(
            state.get("drift_timestamp_buffer", [])
        )
        detector.step_count = state.get("step_count", 0)
        detector.adaptation_count = state.get("adaptation_count", 0)
        detector.last_adaptation = state.get("last_adaptation")
        with detector._normal_buffer_lock:
            detector.normal_data_buffer.extend(
                np.asarray(window, dtype=float)
                for window in state.get("normal_data_buffer", [])
            )
        detector.retrain_count = state.get("retrain_count", 0)
        return detector
