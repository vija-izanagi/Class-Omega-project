class NABEvaluator:
    """Event-level evaluator for inclusive ground-truth index windows."""

    def __init__(self, merge_gap=2):
        self.merge_gap = max(0, int(merge_gap))

    def evaluate(
        self,
        detections,
        ground_truth_windows,
        total_steps,
        event_onsets=None,
    ):
        windows = sorted(
            (int(start), int(end)) for start, end in ground_truth_windows
        )
        if any(start < 0 or end < start or end >= total_steps for start, end in windows):
            raise ValueError("Ground-truth windows must be valid inclusive stream indices.")
        onsets = None
        if event_onsets is not None:
            onsets = [int(index) for index in event_onsets]
            if len(onsets) != len(windows):
                raise ValueError("Provide one onset index for each ground-truth window.")
            if any(index < 0 or index >= total_steps for index in onsets):
                raise ValueError("Event onset indices must be within the stream.")

        indices = sorted(set(int(index) for index in detections))
        if any(index < 0 or index >= total_steps for index in indices):
            raise ValueError("Detection indices must be within the stream.")

        episodes = []
        for index in indices:
            if not episodes or index - episodes[-1][1] > self.merge_gap + 1:
                episodes.append([index, index])
            else:
                episodes[-1][1] = index

        matched_windows = set()
        false_positives = 0
        delays = []
        delay_pairs = []
        for episode_start, episode_end in episodes:
            match = next(
                (
                    window_index
                    for window_index, (start, end) in enumerate(windows)
                    if window_index not in matched_windows
                    and episode_start <= end
                    and episode_end >= start
                ),
                None,
            )
            if match is None:
                false_positives += 1
                continue
            matched_windows.add(match)
            if onsets is None:
                onset = windows[match][0]
                detection = max(episode_start, onset)
            else:
                onset = onsets[match]
                detection = episode_start
            delays.append(max(0, detection - onset))
            delay_pairs.append((detection, onset))

        true_positives = len(matched_windows)
        false_negatives = len(windows) - true_positives
        precision = (
            true_positives / (true_positives + false_positives)
            if true_positives + false_positives
            else 0.0
        )
        recall = true_positives / len(windows) if windows else 0.0
        event_f1 = (
            2 * precision * recall / (precision + recall)
            if precision + recall
            else 0.0
        )
        return {
            "TP": true_positives,
            "FP": false_positives,
            "FN": false_negatives,
            "Total_Events": len(windows),
            "Detection_Episodes": len(episodes),
            "Precision": precision,
            "Recall": recall,
            "Event_F1": event_f1,
            "Mean_Detection_Delay": sum(delays) / len(delays) if delays else None,
            "Detection_Delays": delays,
            "Detection_Delay_Pairs": delay_pairs,
        }
