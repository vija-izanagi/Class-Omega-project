"""Compatibility adapter for callers of the original hybrid detector API."""

from datetime import datetime, timezone

import numpy as np

if __package__:
    from .sentinel import SentinelConfig, SentinelDetector
else:
    from sentinel import SentinelConfig, SentinelDetector


class IntegratedHybridDetector:
    """Adapt the scalar Sentinel detectors to the legacy multivariate API."""

    def __init__(self, time_steps=30, alpha=0.05, cooldown_steps=None):
        self.time_steps = max(2, int(time_steps))
        if not 0.0 < alpha <= 1.0:
            raise ValueError("alpha must be in the interval (0, 1].")
        self.alpha = float(alpha)
        self.cooldown_steps = cooldown_steps
        self.detectors = []
        self.step_count = 0

    def fit(self, df_train, epochs=20, batch_size=32):
        values = (
            df_train.to_numpy(dtype=float)
            if hasattr(df_train, "to_numpy")
            else np.asarray(df_train, dtype=float)
        )
        if values.ndim == 1:
            values = values.reshape(-1, 1)
        if values.ndim != 2 or values.shape[0] < self.time_steps:
            raise ValueError("Training data must contain one or more complete windows.")
        self.detectors = [
            SentinelDetector(
                SentinelConfig(
                    window_size=self.time_steps,
                    ema_alpha=self.alpha,
                    training_epochs=epochs,
                ),
                values[:, feature_index],
            )
            for feature_index in range(values.shape[1])
        ]
        self.step_count = 0
        return self

    def update(self, recent_data, current_val=None):
        if not self.detectors:
            raise RuntimeError("Call fit() with normal training data before update().")
        recent = np.asarray(recent_data, dtype=float)
        point = recent[-1] if recent.ndim == 2 else np.atleast_1d(recent)
        point = np.asarray(point, dtype=float).reshape(-1)
        if current_val is not None:
            point[0] = float(current_val)
        if len(point) != len(self.detectors):
            raise ValueError(
                f"Expected {len(self.detectors)} sensor values, got {len(point)}."
            )
        if not np.isfinite(point).all():
            raise ValueError("Sensor values must be finite.")

        self.step_count += 1
        results = [
            detector.process_step(
                datetime.now(timezone.utc).isoformat(), float(value)
            )
            for detector, value in zip(self.detectors, point)
        ]
        anomalous_results = [
            (index, result)
            for index, result in enumerate(results)
            if result.is_anomalous
        ]
        score = max(result.anomaly_score for result in results)
        evidence = "; ".join(
            f"sensor_{index + 1}: "
            f"{result.evidence.replace('robust standard deviations', 'robust-sigma deviations')}"
            for index, result in anomalous_results
        )
        return {
            "step": self.step_count,
            "sensor_1": float(point[0]),
            "sensor_2": float(point[1]) if len(point) > 1 else 0.0,
            "loss": float(score),
            "threshold": max(
                detector.threshold for detector in self.detectors
            ),
            "score": float(score),
            "anomaly_score": float(score),
            "label": "ANOMALOUS" if anomalous_results else "NORMAL",
            "evidence": evidence or "Within learned baseline.",
            "evidence_details": {
                f"sensor_{index + 1}": result.evidence
                for index, result in anomalous_results
            },
        }
