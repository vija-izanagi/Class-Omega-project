"""Evaluate Sentinel on the CSV files in the workspace's dataset folder."""

import sys
import time
import unittest
from pathlib import Path
from typing import Any

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_DIR = Path(__file__).resolve().parents[3] / "dataset"
REPORT_PATH = Path(__file__).resolve().parent / "model_accuracy_report.md"
sys.path.insert(0, str(PROJECT_ROOT))

from backend.run_nab_benchmark import read_nab_csv
from backend.sentinel import SentinelConfig, SentinelDetector

# The target spike day is specified by the project requirements; the CSV itself
# does not contain row-level ground-truth labels.
REFERENCE_ANOMALY_DATES = {
    "art_load_balancer_spikes.csv": {"2014-04-11"},
    "art_daily_flatmiddle.csv": {"2014-04-11"},
}


def _safe_ratio(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def _evaluate_csv(path: Path) -> dict[str, Any]:
    timestamps, values = read_nab_csv(path)
    labels = REFERENCE_ANOMALY_DATES.get(path.name)
    train_size = max(60, int(len(values) * 0.2))
    if labels:
        first_labeled_anomaly = next(
            (
                index
                for index, timestamp in enumerate(timestamps)
                if timestamp[:10] in labels
            ),
            len(values),
        )
        train_size = min(train_size, first_labeled_anomaly)
    if train_size < 60 or train_size >= len(values):
        raise ValueError(
            f"{path.name} needs at least 60 normal training rows and one test row."
        )

    torch.manual_seed(42)
    detector = SentinelDetector(
        SentinelConfig(
            training_epochs=30,
            enable_background_retraining=False,
        ),
        {
            "timestamp": timestamps[:train_size],
            "value": values[:train_size],
        },
    )
    latencies_ms = []
    predictions = []
    references = []
    alerts = []
    threshold_hits = 0
    magnitude_gated = 0
    baseline_suppressed = 0
    threshold_checks = 0
    zero_value_alerts = 0
    thresholds = []
    try:
        for index in range(train_size, len(values)):
            started = time.perf_counter()
            result = detector.process_step(timestamps[index], float(values[index]))
            latencies_ms.append((time.perf_counter() - started) * 1000.0)
            details = detector.last_decision_details
            threshold = float(details["decision_threshold"])
            thresholds.append(threshold)
            threshold_hit = result.anomaly_score >= threshold
            expected_alert = (
                threshold_hit
                and bool(details["point_trigger"])
                and not bool(details["baseline_suppressed"])
            )
            threshold_checks += 1
            if bool(details["threshold_exceeded"]) != threshold_hit:
                raise AssertionError(
                    f"{path.name} row {index}: threshold diagnostic disagrees "
                    "with anomaly_score >= decision_threshold."
                )
            if result.is_anomalous != expected_alert:
                raise AssertionError(
                    f"{path.name} row {index}: anomaly flag disagrees with "
                    "the documented threshold and safeguard rules."
                )
            threshold_hits += int(threshold_hit)
            magnitude_gated += int(
                threshold_hit and not bool(details["point_trigger"])
            )
            baseline_suppressed += int(bool(details["baseline_suppressed"]))
            zero_value_alerts += int(result.is_anomalous and result.value == 0.0)
            predictions.append(result.is_anomalous)
            if labels is not None:
                references.append(timestamps[index][:10] in labels)
            if result.is_anomalous:
                alerts.append(
                    {
                        "timestamp": timestamps[index],
                        "value": float(values[index]),
                        "score": float(result.anomaly_score),
                        "threshold": threshold,
                    }
                )
    finally:
        detector.stop()

    metrics: dict[str, Any] = {
        "file": str(path.relative_to(DATASET_DIR)),
        "observations": len(values),
        "training_observations": train_size,
        "test_observations": len(predictions),
        "threshold_hits": threshold_hits,
        "magnitude_gated_threshold_hits": magnitude_gated,
        "baseline_suppressed": baseline_suppressed,
        "zero_value_alerts": zero_value_alerts,
        "alerts": alerts,
        "threshold_checks": threshold_checks,
        "thresholds": thresholds,
        "latencies_ms": latencies_ms,
        "labeled": labels is not None,
    }

    if labels is not None:
        tp = sum(
            predicted and expected
            for predicted, expected in zip(predictions, references)
        )
        fp = sum(
            predicted and not expected
            for predicted, expected in zip(predictions, references)
        )
        fn = sum(
            not predicted and expected
            for predicted, expected in zip(predictions, references)
        )
        tn = sum(
            not predicted and not expected
            for predicted, expected in zip(predictions, references)
        )
        precision = _safe_ratio(tp, tp + fp)
        recall = _safe_ratio(tp, tp + fn)
        alert_dates = {alert["timestamp"][:10] for alert in alerts}
        event_tp = len(labels & alert_dates)
        event_fp = len(alert_dates - labels)
        event_fn = len(labels - alert_dates)
        event_precision = _safe_ratio(event_tp, event_tp + event_fp)
        event_recall = _safe_ratio(event_tp, event_tp + event_fn)
        metrics.update(
            {
                "reference_anomaly_dates": sorted(labels),
                "detected_anomaly_dates": sorted(alert_dates),
                "TP": tp,
                "FP": fp,
                "FN": fn,
                "TN": tn,
                "event_TP": event_tp,
                "event_FP": event_fp,
                "event_FN": event_fn,
                "accuracy": _safe_ratio(tp + tn, tp + fp + fn + tn),
                "precision": precision,
                "recall": recall,
                "f1": _safe_ratio(2 * precision * recall, precision + recall),
                "event_precision": event_precision,
                "event_recall": event_recall,
                "event_f1": _safe_ratio(
                    2 * event_precision * event_recall,
                    event_precision + event_recall,
                ),
            }
        )

    return metrics


def _render_report(results: list[dict[str, Any]]) -> str:
    labeled = [result for result in results if result["labeled"]]
    lines = [
        "# Sentinel Dataset Evaluation",
        "",
        f"- Dataset directory: `{DATASET_DIR}`",
        f"- CSV files evaluated: {len(results)}",
        "- Evaluation source: dataset folder only; no archive, synthetic, or external CSVs.",
        "- Decision rule: score >= active dynamic threshold, followed by the configured point-magnitude gate and low-baseline suppression.",
        "",
    ]

    if labeled:
        total_tp = sum(result["TP"] for result in labeled)
        total_fp = sum(result["FP"] for result in labeled)
        total_fn = sum(result["FN"] for result in labeled)
        total_tn = sum(result["TN"] for result in labeled)
        precision = _safe_ratio(total_tp, total_tp + total_fp)
        recall = _safe_ratio(total_tp, total_tp + total_fn)
        f1 = _safe_ratio(2 * precision * recall, precision + recall)
        event_tp = sum(result["event_TP"] for result in labeled)
        event_fp = sum(result["event_FP"] for result in labeled)
        event_fn = sum(result["event_FN"] for result in labeled)
        event_precision = _safe_ratio(event_tp, event_tp + event_fp)
        event_recall = _safe_ratio(event_tp, event_tp + event_fn)
        event_f1 = _safe_ratio(
            2 * event_precision * event_recall,
            event_precision + event_recall,
        )
        accuracy = _safe_ratio(
            total_tp + total_tn,
            total_tp + total_fp + total_fn + total_tn,
        )
        lines.extend(
            [
                "## Reference-label metrics",
                "",
                f"- Accuracy: {accuracy:.4f}",
                f"- Precision: {precision:.4f}",
                f"- Recall: {recall:.4f}",
                f"- F1: {f1:.4f}",
                f"- Confusion counts: TP={total_tp}, FP={total_fp}, FN={total_fn}, TN={total_tn}",
                f"- Event-day precision / recall / F1: "
                f"{event_precision:.4f} / {event_recall:.4f} / {event_f1:.4f}",
                "",
                "The target CSV has no row-level label file. For this report only, "
                "the 2014-04-11 date is treated as the positive reference window "
                "because the project requirements identify that anomaly period. "
                "These are date-level proxy metrics, not independently verified labels.",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "## Reference-label metrics",
                "",
                "Accuracy, precision, recall, and F1 are unavailable: no labels are "
                "defined for the CSV files in the dataset folder.",
                "",
            ]
        )

    lines.extend(["## Per-file results", ""])
    for result in results:
        latencies = np.asarray(result["latencies_ms"], dtype=float)
        thresholds = np.asarray(result["thresholds"], dtype=float)
        lines.extend(
            [
                f"### `{result['file']}`",
                "",
                f"- Observations: {result['observations']:,} "
                f"(training {result['training_observations']:,}, "
                f"testing {result['test_observations']:,})",
                f"- Threshold crossings: {result['threshold_hits']:,}",
                f"- Crossings blocked by point-magnitude gate: "
                f"{result['magnitude_gated_threshold_hits']:,}",
                f"- Low-baseline suppressions: {result['baseline_suppressed']:,}",
                f"- Reported anomalies: {len(result['alerts']):,}",
                f"- Zero-valued anomaly alerts: {result['zero_value_alerts']:,}",
                f"- Threshold/decision consistency checks: "
                f"{result['threshold_checks']:,}/{result['threshold_checks']:,} passed",
                (
                    f"- Dynamic threshold: min {np.min(thresholds):.4f}, "
                    f"median {np.median(thresholds):.4f}, "
                    f"max {np.max(thresholds):.4f}, "
                    f"final {thresholds[-1]:.4f}"
                    if thresholds.size
                    else "- Dynamic threshold: unavailable"
                ),
                (
                    f"- Inference latency: mean {np.mean(latencies):.3f} ms, "
                    f"p95 {np.percentile(latencies, 95):.3f} ms, "
                    f"max {np.max(latencies):.3f} ms"
                    if latencies.size
                    else "- Inference latency: unavailable"
                ),
            ]
        )
        if result["labeled"]:
            lines.extend(
                [
                    f"- Reference anomaly date(s): "
                    f"{', '.join(result['reference_anomaly_dates'])}",
                    f"- Accuracy / precision / recall / F1: "
                    f"{result['accuracy']:.4f} / {result['precision']:.4f} / "
                    f"{result['recall']:.4f} / {result['f1']:.4f}",
                    f"- Event-day precision / recall / F1: "
                    f"{result['event_precision']:.4f} / "
                    f"{result['event_recall']:.4f} / {result['event_f1']:.4f}",
                ]
            )
        lines.append("")

    lines.extend(
        [
            "## Interpretation",
            "",
            "A threshold crossing is not silently discarded: the report separately "
            "counts crossings that are gated by point magnitude and those "
            "suppressed as baseline returns. A threshold candidate is excluded "
            "from adaptive normal-score history so a missed/gated candidate "
            "cannot raise its own future threshold.",
            "",
        ]
    )
    return "\n".join(lines)


class ModelAccuracyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not DATASET_DIR.is_dir():
            raise FileNotFoundError(
                f"Required dataset folder does not exist: {DATASET_DIR}"
            )
        csv_files = sorted(DATASET_DIR.rglob("*.csv"))
        if not csv_files:
            raise FileNotFoundError(f"No CSV files found in {DATASET_DIR}.")
        cls.results = [_evaluate_csv(path) for path in csv_files]
        REPORT_PATH.write_text(_render_report(cls.results), encoding="utf-8")

    def test_only_dataset_folder_csvs_are_evaluated(self):
        self.assertTrue(self.results)
        self.assertTrue(
            all(
                Path(DATASET_DIR / result["file"]).is_file()
                for result in self.results
            )
        )

    def test_threshold_crossings_match_anomaly_decisions(self):
        self.assertTrue(
            all(
                result["threshold_checks"] == result["test_observations"]
                for result in self.results
            )
        )

    def test_target_anomaly_is_detected_without_zero_value_alerts(self):
        for result in self.results:
            self.assertEqual(result["zero_value_alerts"], 0, result["file"])
            if Path(result["file"]).name in REFERENCE_ANOMALY_DATES:
                self.assertTrue(
                    result["alerts"],
                    "No anomaly alerts were produced for the target dataset.",
                )
                self.assertTrue(
                    all(
                        alert["timestamp"].startswith("2014-04-11")
                        for alert in result["alerts"]
                    ),
                    "Target dataset produced alerts outside the expected spike day.",
                )

    def test_report_is_written_with_dataset_and_decision_metrics(self):
        report = REPORT_PATH.read_text(encoding="utf-8")
        self.assertIn("# Sentinel Dataset Evaluation", report)
        self.assertIn("dataset folder only", report)
        self.assertIn("Threshold/decision consistency checks", report)


if __name__ == "__main__":
    unittest.main()
