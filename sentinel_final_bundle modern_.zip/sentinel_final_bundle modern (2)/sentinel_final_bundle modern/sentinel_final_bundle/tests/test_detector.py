import unittest

import numpy as np

from backend.detector import IntegratedHybridDetector
from backend.nab_evaluator import NABEvaluator


class DetectorTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(7)
        phase = np.arange(500) * 0.05
        self.training = np.column_stack(
            (
                np.sin(phase) + rng.normal(0, 0.05, len(phase)),
                np.cos(phase) + rng.normal(0, 0.05, len(phase)),
            )
        )
        self.detector = IntegratedHybridDetector(time_steps=30).fit(self.training)

    def tearDown(self):
        for detector in self.detector.detectors:
            detector.stop()

    def test_normal_points_are_scored_and_labelled(self):
        point = self.training[-1]
        result = self.detector.update(point)
        self.assertEqual(result["label"], "NORMAL")
        self.assertGreaterEqual(result["anomaly_score"], 0.0)
        self.assertLessEqual(result["anomaly_score"], 1.0)
        self.assertIn("Within learned baseline", result["evidence"])

    def test_spike_is_anomalous_with_interpretable_evidence(self):
        result = self.detector.update(self.training[-1] + np.array([12.0, -10.0]))
        self.assertEqual(result["label"], "ANOMALOUS")
        self.assertGreaterEqual(result["anomaly_score"], 0.5)
        self.assertIn("robust-sigma", result["evidence"])
        self.assertTrue(result["evidence_details"])

    def test_zero_return_after_spikes_is_not_anomalous(self):
        for _ in range(8):
            self.detector.update([5.0, -5.0])

        result = self.detector.update([0.0, 0.0])

        self.assertEqual(result["label"], "NORMAL")

    def test_invalid_observation_is_rejected(self):
        with self.assertRaises(ValueError):
            self.detector.update([np.nan, 0.0])


class EvaluatorTests(unittest.TestCase):
    def test_event_metrics_merge_detection_bursts_and_measure_delay(self):
        result = NABEvaluator(merge_gap=2).evaluate(
            detections=[12, 13, 15, 40], ground_truth_windows=[(10, 20)], total_steps=50
        )
        self.assertEqual(result["TP"], 1)
        self.assertEqual(result["FP"], 1)
        self.assertEqual(result["FN"], 0)
        self.assertEqual(result["Detection_Delays"], [2])
        self.assertAlmostEqual(result["Event_F1"], 2 / 3)

    def test_no_detections_counts_each_missed_event(self):
        result = NABEvaluator().evaluate([], [(2, 5), (10, 15)], 20)
        self.assertEqual(result["FN"], 2)
        self.assertEqual(result["Event_F1"], 0.0)

    def test_detection_delay_is_measured_from_labeled_onset(self):
        result = NABEvaluator().evaluate(
            detections=[22],
            ground_truth_windows=[(10, 30)],
            total_steps=40,
            event_onsets=[20],
        )
        self.assertEqual(result["Detection_Delays"], [2])
        self.assertEqual(result["Detection_Delay_Pairs"], [(22, 20)])

    def test_pre_onset_warning_has_zero_onset_delay(self):
        result = NABEvaluator().evaluate(
            detections=[12],
            ground_truth_windows=[(10, 30)],
            total_steps=40,
            event_onsets=[20],
        )
        self.assertEqual(result["Detection_Delays"], [0])
        self.assertEqual(result["Detection_Delay_Pairs"], [(12, 20)])


if __name__ == "__main__":
    unittest.main()
