import asyncio
import os
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from typing import cast
from unittest.mock import patch

import numpy as np
from fastapi import Request, WebSocket
from starlette.websockets import WebSocketDisconnect

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.sentinel import AnomalyResult, SentinelConfig, SentinelDetector
from backend.run_nab_benchmark import (
    default_dataset_dir,
    evaluate_nab,
    read_nab_csv,
)
from backend import main as dashboard


def make_normal_data(count=200):
    phase = np.arange(count) * 0.08
    return 10.0 + 0.3 * np.sin(phase)


def make_detector():
    config = SentinelConfig(training_epochs=10, enable_background_retraining=False)
    return SentinelDetector(config, make_normal_data())


class SentinelTests(unittest.TestCase):
    def test_dashboard_restarts_detector_after_dataset_is_consumed(self):
        original_state = (
            dashboard.detector,
            dashboard.stream_timestamps,
            dashboard.stream_values,
            dashboard.stream_index,
            dashboard.stream_step,
            dashboard.warmup_values,
            dashboard.warmup_timestamps,
            dashboard.warmup_size,
            dashboard.pending_payload,
            dashboard.pending_index,
        )
        warmup = make_normal_data(100)
        dashboard.detector = None
        dashboard.stream_timestamps = [str(index) for index in range(150)]
        dashboard.stream_values = np.concatenate((warmup, make_normal_data(50)))
        dashboard.stream_index = len(dashboard.stream_values)
        dashboard.stream_step = 77
        dashboard.warmup_values = warmup
        dashboard.warmup_timestamps = [str(index) for index in range(len(warmup))]
        dashboard.warmup_size = len(warmup)
        try:
            self.assertTrue(dashboard.reset_completed_stream())
            self.assertEqual(dashboard.stream_index, len(warmup))
            self.assertEqual(dashboard.stream_step, 0)
            active_detector = dashboard.detector
            if active_detector is None:
                self.fail("Reset did not activate a detector.")
            self.assertTrue(active_detector.is_fitted)
            self.assertFalse(dashboard.reset_completed_stream())
        finally:
            if dashboard.detector is not None:
                dashboard.detector.stop()
            (
                dashboard.detector,
                dashboard.stream_timestamps,
                dashboard.stream_values,
                dashboard.stream_index,
                dashboard.stream_step,
                dashboard.warmup_values,
                dashboard.warmup_timestamps,
                dashboard.warmup_size,
                dashboard.pending_payload,
                dashboard.pending_index,
            ) = original_state

    def test_dashboard_streams_at_twenty_observations_per_second(self):
        self.assertEqual(dashboard.STREAM_DELAY_SECONDS, 0.05)

    def test_smoke_normal_stream(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        for index in range(100):
            result = detector.process_step(
                start + timedelta(minutes=index),
                10.0 + 0.3 * np.sin((200 + index) * 0.08),
            )
            self.assertIsInstance(result, AnomalyResult)
            self.assertEqual(
                set(result.__dataclass_fields__),
                {"timestamp", "value", "anomaly_score", "is_anomalous", "evidence"},
            )
            self.assertFalse(result.is_anomalous, result.evidence)
            self.assertGreaterEqual(result.anomaly_score, 0.0)
            self.assertLessEqual(result.anomaly_score, 1.0)

    def test_spike_is_reported_as_anomaly(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        for index in range(20):
            detector.process_step(
                start + timedelta(minutes=index),
                10.0 + 0.3 * np.sin((200 + index) * 0.08),
            )
        result = detector.process_step(start + timedelta(minutes=20), 500.0)
        self.assertTrue(result.is_anomalous)
        self.assertIn("Spike", result.evidence)

    def test_first_point_of_a_level_shift_is_flagged(self):
        normal = 10.0 + 0.2 * np.sin(np.arange(200) * 0.08)
        detector = SentinelDetector(
            SentinelConfig(enable_background_retraining=False),
            normal,
        )
        onset = datetime(2026, 1, 1)
        result = detector.process_step(onset, 11.0)
        self.assertTrue(result.is_anomalous)
        self.assertEqual(result.timestamp, onset.isoformat())

    def test_fit_uses_held_out_tail_for_calibration_not_baseline(self):
        values = np.concatenate((np.full(160, 10.0), np.full(40, 100.0)))
        detector = SentinelDetector(
            SentinelConfig(enable_background_retraining=False),
            values,
        )
        self.assertAlmostEqual(detector.scaler_center, 10.0)

    def test_default_training_uses_validation_early_stopping(self):
        detector = SentinelDetector(
            SentinelConfig(enable_background_retraining=False),
            make_normal_data(400),
        )
        self.assertEqual(detector.config.training_epochs, 30)
        self.assertGreater(detector.training_epochs_completed, 0)
        self.assertLessEqual(
            detector.training_epochs_completed,
            detector.config.training_epochs,
        )
        self.assertGreaterEqual(
            detector.config.training_patience, 1
        )

    def test_frequency_only_change_is_suppressed_without_point_magnitude_shift(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        results = []
        thresholds = []
        for index in range(100):
            results.append(
                detector.process_step(
                    start + timedelta(minutes=index),
                    10.0 + 0.3 * np.sin((200 + index) * 0.55),
                )
            )
            thresholds.append(detector.last_decision_threshold)
        self.assertTrue(
            any(
                result.anomaly_score >= threshold
                for result, threshold in zip(results, thresholds)
            )
        )
        self.assertFalse(
            any(result.is_anomalous for result in results),
            "Context-only scores must not alert without a point-magnitude trigger.",
        )

    def test_hour_conditioned_baseline_detects_flat_regime_at_onset(self):
        start = datetime(2026, 1, 1)
        timestamps = [
            (start + timedelta(minutes=5 * index)).isoformat()
            for index in range(5 * 24 * 12)
        ]
        values = np.asarray(
            [
                20.0
                + 20.0
                * np.sin(
                    2.0
                    * np.pi
                    * (timestamp.hour + timestamp.minute / 60.0)
                    / 24.0
                )
                for timestamp in (
                    datetime.fromisoformat(timestamp) for timestamp in timestamps
                )
            ],
            dtype=float,
        )
        warmup_size = int(len(values) * 0.7)
        detector = SentinelDetector(
            SentinelConfig(training_epochs=5, enable_background_retraining=False),
            {"timestamp": timestamps[:warmup_size], "value": values[:warmup_size]},
        )
        self.assertTrue(detector.seasonal_enabled)

        normal_results = [
            detector.process_step(timestamps[index], values[index])
            for index in range(warmup_size, 4 * 24 * 12)
        ]
        self.assertFalse(
            any(result.is_anomalous for result in normal_results),
            "Normal daily cycles should not trigger the time-conditioned baseline.",
        )
        anomaly_results = [
            detector.process_step(
                timestamps[index],
                40.0,
            )
            for index in range(4 * 24 * 12, len(values))
        ]
        first_detection = next(
            (
                index
                for index, result in enumerate(anomaly_results)
                if result.is_anomalous
            ),
            None,
        )
        self.assertIsNotNone(first_detection, "Flat regime was not detected.")
        if first_detection is None:
            self.fail("Flat regime detection index was not set.")
        self.assertLessEqual(first_detection, 2)
        self.assertIn("Seasonal Context", anomaly_results[first_detection].evidence)
        anomaly_count = sum(result.is_anomalous for result in anomaly_results)
        self.assertGreaterEqual(
            anomaly_count,
            int(len(anomaly_results) * 0.70),
            "The hourly model should flag sustained points outside the learned profile.",
        )
        self.assertEqual(detector.adaptation_count, 0)

    def test_state_persistence_restores_buffers_and_ema(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        for index in range(12):
            detector.process_step(
                start + timedelta(minutes=index),
                10.0 + 0.3 * np.sin((200 + index) * 0.08),
            )
        with tempfile.TemporaryDirectory() as folder:
            filepath = os.path.join(folder, "sentinel-state.pt")
            detector.save_state(filepath)
            restored = SentinelDetector.load_state(filepath)
        self.assertTrue(
            all(
                np.array_equal(
                    tensor.detach().numpy(),
                    restored.model.state_dict()[name].detach().numpy(),
                )
                for name, tensor in detector.model.state_dict().items()
            )
        )
        self.assertEqual(list(restored.value_buffer), list(detector.value_buffer))
        self.assertEqual(list(restored.timestamp_buffer), list(detector.timestamp_buffer))
        self.assertEqual(list(restored.score_history), list(detector.score_history))
        self.assertEqual(
            [window.tolist() for window in restored.normal_data_buffer],
            [window.tolist() for window in detector.normal_data_buffer],
        )
        self.assertEqual(restored.ema_score, detector.ema_score)
        self.assertEqual(restored.threshold, detector.threshold)
        self.assertEqual(restored.point_threshold, detector.point_threshold)
        self.assertEqual(
            restored.config.autoencoder_weight,
            detector.config.autoencoder_weight,
        )
        self.assertEqual(
            list(restored.point_exceedance_buffer),
            list(detector.point_exceedance_buffer),
        )
        np.testing.assert_array_equal(restored.hourly_center, detector.hourly_center)
        np.testing.assert_array_equal(restored.hourly_scale, detector.hourly_scale)
        self.assertEqual(restored.seasonal_enabled, detector.seasonal_enabled)
        self.assertEqual(restored.process_step(start, 10.0), detector.process_step(start, 10.0))
        restored.stop()

    def test_baseline_return_after_spikes_is_suppressed_and_logged(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        for index in range(12):
            detector.process_step(
                start + timedelta(minutes=index),
                500.0,
            )

        result = detector.process_step(start + timedelta(minutes=12), 0.0)

        self.assertFalse(result.is_anomalous)
        self.assertLessEqual(result.value, detector.config.baseline_tolerance)
        if result.anomaly_score >= detector.last_decision_threshold:
            self.assertIn("suppressed_baseline_return", result.evidence)

    def test_score_weight_slider_updates_live_detector_fusion(self):
        detector = make_detector()
        hybrid_threshold = detector.threshold
        detector.set_autoencoder_weight(0.25)
        self.assertEqual(detector.config.autoencoder_weight, 0.25)
        self.assertAlmostEqual(
            detector._fuse_scores(statistical_score=1.0, autoencoder_score=0.0),
            0.75,
        )
        self.assertNotEqual(detector.threshold, hybrid_threshold)
        detector.set_autoencoder_weight(1.0)
        self.assertEqual(detector.detection_mode, "machine_learning")
        detector.set_autoencoder_weight(0.0)
        self.assertEqual(detector.detection_mode, "statistics")
        with self.assertRaises(ValueError):
            detector.set_autoencoder_weight(1.1)

    def test_reviewed_new_normal_dataset_recalibrates_baseline(self):
        detector = make_detector()
        shifted_normal = 25.0 + 0.8 * np.sin(np.arange(500) * 0.08)
        detector.update_normal_baseline(shifted_normal)
        self.assertAlmostEqual(detector.scaler_center, 25.0, delta=0.1)
        start = datetime(2026, 1, 1)
        results = [
            detector.process_step(
                start + timedelta(minutes=index),
                25.0 + 0.8 * np.sin((500 + index) * 0.08),
            )
            for index in range(50)
        ]
        self.assertFalse(
            any(result.is_anomalous for result in results),
            "Reviewed new-normal stream should not keep triggering old-baseline alerts.",
        )

    def test_sustained_stream_shift_is_learned_as_new_normal(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        rng = np.random.default_rng(17)
        transition_results = []
        for index in range(700):
            value = 30.0 + 0.4 * np.sin(index * 0.07) + rng.normal(0, 0.04)
            transition_results.append(
                detector.process_step(start + timedelta(minutes=index), value)
            )
        self.assertEqual(detector.adaptation_count, 1)
        self.assertGreater(detector.scaler_center, 29.0)
        after_adaptation = [
            detector.process_step(
                start + timedelta(minutes=700 + index),
                30.0 + 0.4 * np.sin((700 + index) * 0.07) + rng.normal(0, 0.04),
            )
            for index in range(100)
        ]
        self.assertLessEqual(
            sum(result.is_anomalous for result in after_adaptation),
            2,
            "A stable learned regime should not cause a continuing alert stream.",
        )

    def test_single_spike_does_not_trigger_baseline_adaptation(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        detector.process_step(start, 500.0)
        for index in range(400):
            detector.process_step(
                start + timedelta(minutes=index + 1),
                10.0 + 0.3 * np.sin(index * 0.08),
            )
        self.assertEqual(detector.adaptation_count, 0)

    def test_sustained_variance_drop_is_learned_as_new_normal(self):
        detector = make_detector()
        original_scale = detector.scaler_scale
        start = datetime(2026, 1, 1)
        rng = np.random.default_rng(91)
        for index in range(400):
            value = 10.0 + 0.025 * np.sin(index * 0.08) + rng.normal(0, 0.005)
            detector.process_step(start + timedelta(minutes=index), value)

        self.assertEqual(detector.adaptation_count, 1)
        self.assertLess(
            (detector.scaler_scale / original_scale) ** 2,
            detector.config.variance_change_ratio,
        )
        self.assertGreaterEqual(detector.threshold, 0.05)
        after_adaptation = [
            detector.process_step(
                start + timedelta(minutes=400 + index),
                10.0 + 0.025 * np.sin((400 + index) * 0.08)
                + rng.normal(0, 0.005),
            )
            for index in range(100)
        ]
        self.assertFalse(any(result.is_anomalous for result in after_adaptation))

    def test_threshold_is_dynamic_with_configured_floor(self):
        config = SentinelConfig(
            threshold_floor=0.05,
            training_epochs=5,
            enable_background_retraining=False,
        )
        detector = SentinelDetector(config, make_normal_data())
        self.assertGreaterEqual(detector.threshold, 0.05)

        detector.score_history.clear()
        detector.score_history.extend([0.1, 0.2, 0.3, 0.4])
        detector.ema_score = 0.25
        detector._refresh_threshold()
        self.assertAlmostEqual(
            detector.threshold,
            max(
                0.05,
                detector.calibrated_threshold,
                np.percentile(
                    [0.1, 0.2, 0.3, 0.4], config.threshold_percentile
                )
                + config.ema_alpha * 0.25,
            ),
        )

    def test_recalibrated_threshold_tracks_new_normal_distribution(self):
        detector = make_detector()
        original_threshold = detector.threshold
        normal_data = 10.0 + np.random.default_rng(10).normal(0, 0.015, 1000)
        detector.update_normal_baseline(normal_data)

        self.assertGreaterEqual(detector.threshold, 0.05)
        self.assertLess(detector.threshold, original_threshold)

    def test_velocity_and_cyclical_time_features_are_computed(self):
        detector = make_detector()
        timestamp = datetime(2026, 10, 26, 12, 0)
        previous = detector.value_buffer[-1]
        value = previous + 0.25
        detector.process_step(timestamp, value)

        self.assertAlmostEqual(detector.last_features["velocity"], 0.25)
        self.assertAlmostEqual(
            detector.last_features["hour_sin"],
            np.sin(2.0 * np.pi * 12.0 / 24.0),
        )
        self.assertAlmostEqual(
            detector.last_features["weekday_sin"],
            np.sin(2.0 * np.pi * timestamp.weekday() / 7.0),
        )

    def test_training_window_sampling_is_bounded_for_large_datasets(self):
        detector = make_detector()
        windows = detector._make_windows(np.arange(100_000, dtype=float))
        self.assertEqual(len(windows), detector.TRAINING_WINDOW_LIMIT)

    def test_fast_csv_loader_filters_nonfinite_values(self):
        with tempfile.TemporaryDirectory() as folder:
            filepath = Path(folder) / "stream.csv"
            filepath.write_text(
                "timestamp,value\n2026-01-01T00:00:00,1.0\n"
                "2026-01-01T00:01:00,NaN\n2026-01-01T00:02:00,3.0\n",
                encoding="utf-8",
            )
            timestamps, values = read_nab_csv(filepath)

        self.assertEqual(timestamps, ["2026-01-01T00:00:00", "2026-01-01T00:02:00"])
        np.testing.assert_array_equal(values, [1.0, 3.0])

    def test_csv_loader_accepts_headerless_rows_with_spaces_after_comma(self):
        with tempfile.TemporaryDirectory() as folder:
            csv_path = Path(folder) / "observations.csv"
            start = datetime(2014, 4, 2, 7, 15)
            rows = [
                f"{(start + timedelta(minutes=5 * index)):%Y-%m-%d %H:%M:%S}, 20.0\n"
                for index in range(61)
            ]
            csv_path.write_text("".join(rows), encoding="utf-8")

            timestamps, values = read_nab_csv(csv_path)
            loaded_timestamps, loaded_values, file_count = dashboard.load_dataset_stream(
                Path(folder)
            )

        self.assertEqual(len(timestamps), 61)
        self.assertEqual(timestamps[0], "2014-04-02 07:15:00")
        np.testing.assert_array_equal(values, np.full(61, 20.0))
        self.assertEqual(loaded_timestamps, timestamps)
        np.testing.assert_array_equal(loaded_values, values)
        self.assertEqual(file_count, 1)

    def test_default_dataset_directory_finds_workspace_dataset(self):
        with tempfile.TemporaryDirectory() as folder:
            workspace = Path(folder)
            backend_dir = workspace / "project" / "backend"
            backend_dir.mkdir(parents=True)
            dataset_dir = workspace / "dataset"
            dataset_dir.mkdir()
            observations = [
                f"2026-01-01T{index // 60:02d}:{index % 60:02d}:00,{index}"
                for index in range(61)
            ]
            (dataset_dir / "observations.csv").write_text(
                "timestamp,value\n" + "\n".join(observations) + "\n",
                encoding="utf-8",
            )
            target_file = (
                workspace
                / "archive"
                / "artificialWithAnomaly"
                / "artificialWithAnomaly"
                / "art_load_balancer_spikes.csv"
            )
            target_file.parent.mkdir(parents=True)
            target_file.write_text(
                "timestamp,value\n"
                + "\n".join(
                    f"2026-02-01T{index // 60:02d}:{index % 60:02d}:00,{100 + index}"
                    for index in range(61)
                )
                + "\n",
                encoding="utf-8",
            )
            module_path = backend_dir / "run_nab_benchmark.py"
            with patch("backend.run_nab_benchmark.__file__", str(module_path)):
                self.assertEqual(default_dataset_dir(), dataset_dir)

            with patch.object(dashboard, "default_dataset_dir", return_value=dataset_dir):
                timestamps, values, file_count = dashboard.load_dataset_stream()

        self.assertEqual(len(timestamps), 61)
        self.assertEqual(timestamps[0], "2026-01-01T00:00:00")
        self.assertEqual(timestamps[-1], "2026-01-01T01:00:00")
        np.testing.assert_array_equal(values, np.arange(61, dtype=float))
        self.assertEqual(file_count, 1)

    def test_dataset_warmup_covers_temporal_profile_and_small_uploads(self):
        self.assertEqual(dashboard.dataset_warmup_size(4032), 806)
        self.assertEqual(dashboard.dataset_warmup_size(120), 60)

    def test_dashboard_control_message_updates_live_score_weights(self):
        original_detector = dashboard.detector
        controlled_detector = make_detector()

        class ControlSocket:
            received = False

            async def receive_text(self):
                if self.received:
                    raise WebSocketDisconnect()
                self.received = True
                return '{"type":"score_weights","autoencoder_weight":0.35}'

        dashboard.detector = controlled_detector
        try:
            asyncio.run(
                dashboard.receive_dashboard_controls(cast(WebSocket, ControlSocket()))
            )
            self.assertEqual(controlled_detector.config.autoencoder_weight, 0.35)
        finally:
            controlled_detector.stop()
            dashboard.detector = original_detector

    def test_custom_csv_upload_retrains_and_replaces_active_stream(self):
        class UploadRequest:
            async def body(self):
                return (
                    "timestamp,value\n"
                    + "\n".join(
                        f"2026-03-01 {index // 60:02d}:{index % 60:02d}:00,"
                        f"{(15.0 if index == 75 else 5.0 + 0.2 * np.sin(index / 10)):.6f}"
                        for index in range(120)
                    )
                ).encode("utf-8")

        original_globals = (
            dashboard.detector,
            dashboard.stream_dataset_name,
            dashboard.stream_timestamps,
            dashboard.stream_values,
            dashboard.stream_index,
            dashboard.stream_step,
            dashboard.warmup_timestamps,
            dashboard.warmup_values,
            dashboard.warmup_size,
            dashboard.pending_payload,
            dashboard.pending_index,
        )
        try:
            result = asyncio.run(
                dashboard.upload_dataset(
                    cast(Request, UploadRequest()),
                    filename="custom.csv",
                )
            )
            self.assertEqual(result["dataset"], "custom.csv")
            self.assertEqual(result["observations"], 120)
            self.assertEqual(result["training_observations"], 60)
            self.assertEqual(dashboard.stream_timestamps[0], "2026-03-01 00:00:00")
            self.assertEqual(dashboard.stream_index, 60)
            active_detector = dashboard.detector
            if active_detector is None:
                self.fail("CSV upload did not activate a detector.")
            self.assertTrue(active_detector.is_fitted)
            anomaly_results = [
                active_detector.process_step(
                    dashboard.stream_timestamps[index],
                    float(dashboard.stream_values[index]),
                )
                for index in range(60, len(dashboard.stream_values))
            ]
            spike_result = anomaly_results[15]
            self.assertTrue(spike_result.is_anomalous, spike_result.evidence)
            self.assertIn("point threshold", spike_result.evidence)
            self.assertEqual(
                active_detector.last_decision_details["mode"],
                "hybrid",
            )
        finally:
            if dashboard.detector is not original_globals[0] and dashboard.detector:
                dashboard.detector.stop()
            (
                dashboard.detector,
                dashboard.stream_dataset_name,
                dashboard.stream_timestamps,
                dashboard.stream_values,
                dashboard.stream_index,
                dashboard.stream_step,
                dashboard.warmup_timestamps,
                dashboard.warmup_values,
                dashboard.warmup_size,
                dashboard.pending_payload,
                dashboard.pending_index,
            ) = original_globals

    def test_default_target_stream_flags_april_11_flat_regime(self):
        target_csv = (
            Path(__file__).resolve().parents[3]
            / "dataset"
            / "art_daily_flatmiddle.csv"
        )
        if not target_csv.is_file():
            self.skipTest("Workspace dataset folder does not include flatmiddle CSV.")

        timestamps, values, _ = dashboard.load_dataset_stream()
        warmup_size = dashboard.dataset_warmup_size(len(values))
        detector = dashboard.create_dashboard_detector(
            values[:warmup_size],
            timestamps[:warmup_size],
        )
        detections = []
        try:
            for index in range(warmup_size, len(values)):
                result = detector.process_step(
                    timestamps[index],
                    float(values[index]),
                )
                if result.is_anomalous:
                    detections.append((timestamps[index], result.value))
        finally:
            detector.stop()

        self.assertTrue(detections, "April 11 flat regime was not detected.")
        self.assertTrue(all(timestamp.startswith("2014-04-11") for timestamp, _ in detections))
        self.assertFalse(any(value == 0.0 for _, value in detections))

    def test_dataset_directory_processes_every_csv_without_labels(self):
        with tempfile.TemporaryDirectory() as folder:
            data_dir = Path(folder)
            timestamps = [
                f"2026-01-01T00:{index:02d}:00" for index in range(100)
            ]
            for filename, offset in (("first.csv", 0.0), ("nested/second.csv", 2.0)):
                csv_path = data_dir / filename
                csv_path.parent.mkdir(parents=True, exist_ok=True)
                with csv_path.open("w", encoding="utf-8") as file:
                    file.write("timestamp,value\n")
                    for index, timestamp in enumerate(timestamps):
                        file.write(f"{timestamp},{offset + np.sin(index / 10):.6f}\n")

            args = SimpleNamespace(
                data_dir=str(data_dir),
                labels=None,
                window_fraction=0.1,
                train_fraction=0.1,
                epochs=1,
                threshold_percentile=99.95,
            )
            results, total_rows, training_rows = evaluate_nab(args)

        self.assertEqual(len(results), 2)
        self.assertEqual(total_rows, 200)
        self.assertEqual(training_rows, 120)
        self.assertTrue(all(result["processed_rows"] == 40 for result in results))

    def test_anomaly_decision_uses_dynamic_threshold_directly(self):
        detector = make_detector()
        start = datetime(2026, 1, 1)
        for index in range(30):
            result = detector.process_step(start + timedelta(minutes=index), 500.0)
            details = detector.last_decision_details
            self.assertEqual(
                details["threshold_exceeded"],
                result.anomaly_score >= details["decision_threshold"],
            )
            self.assertEqual(
                result.is_anomalous,
                details["threshold_exceeded"]
                and details["point_trigger"]
                and not details["baseline_suppressed"],
            )
            if result.is_anomalous:
                self.assertIn("Spike", result.evidence)
                break
        else:
            self.fail("A point exceeding the active dynamic threshold was not flagged.")

    def test_threshold_candidates_do_not_pollute_normal_score_history(self):
        detector = make_detector()
        detector.point_threshold = 1_000_000.0
        previous_threshold = detector.threshold
        previous_history = list(detector.score_history)

        result = detector.process_step("2026-01-01T00:00:00", 500.0)

        self.assertTrue(detector.last_decision_details["threshold_exceeded"])
        self.assertFalse(detector.last_decision_details["point_trigger"])
        self.assertFalse(result.is_anomalous)
        self.assertEqual(list(detector.score_history), previous_history)
        self.assertEqual(detector.threshold, previous_threshold)

    def test_background_retraining_hot_swaps_weights_and_stops(self):
        warmup = make_normal_data()
        detector = SentinelDetector(
            SentinelConfig(
                training_epochs=2,
                retrain_interval=50,
                enable_background_retraining=True,
            ),
            warmup,
        )
        original_weights = {
            name: tensor.detach().clone()
            for name, tensor in detector.model.state_dict().items()
        }
        start = datetime(2026, 1, 1)
        latencies = []
        for index in range(150):
            value = 10.0 + 0.3 * np.sin((200 + index) * 0.08)
            started = time.perf_counter()
            detector.process_step(start + timedelta(minutes=index), value)
            latencies.append((time.perf_counter() - started) * 1000.0)

        deadline = time.monotonic() + 20.0
        while detector.retrain_count == 0 and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertGreater(detector.retrain_count, 0)
        self.assertTrue(
            any(
                not np.array_equal(original_weights[name].numpy(), tensor.numpy())
                for name, tensor in detector.model.state_dict().items()
            ),
            "Background retraining did not update any model weights.",
        )
        self.assertLess(max(latencies), 5.0, "Streaming inference exceeded 5 ms.")
        detector.stop()
        retrain_thread = detector._retrain_thread
        if retrain_thread is None:
            self.fail("Background retraining thread was not initialized.")
        self.assertFalse(retrain_thread.is_alive())

    def test_failed_baseline_update_keeps_active_detector_unchanged(self):
        detector = make_detector()
        previous_center = detector.scaler_center
        previous_values = list(detector.value_buffer)
        with self.assertRaises(ValueError):
            detector.update_normal_baseline([1.0, 2.0, 3.0])
        self.assertEqual(detector.scaler_center, previous_center)
        self.assertEqual(list(detector.value_buffer), previous_values)

    def test_invalid_values_return_safe_results_without_crashing(self):
        detector = make_detector()
        result = detector.process_step("2026-01-01T00:00:00", float("nan"))
        self.assertFalse(result.is_anomalous)
        self.assertEqual(result.value, 0.0)
        self.assertIn("Inference error", result.evidence)

    def test_large_randomized_nab_like_stream(self):
        rng = np.random.default_rng(42)
        count = 20_000
        innovations = rng.normal(0, 0.12, count)
        correlated_noise = np.empty(count, dtype=float)
        correlated_noise[0] = innovations[0]
        for index in range(1, count):
            correlated_noise[index] = (
                0.96 * correlated_noise[index - 1] + innovations[index]
            )
        slow_drift = np.cumsum(rng.normal(0, 0.0015, count))
        values = (
            10.0
            + slow_drift
            + correlated_noise
            + rng.normal(0, 0.08, count)
        )
        anomaly_points = [4_000, 9_000, 14_000, 18_000]
        windows = []
        for index in anomaly_points:
            values[index] += 15.0
            windows.append((index, index + 10))

        detector = SentinelDetector(
            SentinelConfig(
                training_epochs=5,
                enable_background_retraining=False,
            ),
            values[:1000],
        )
        detections = []
        start = datetime(2026, 1, 1)
        for index, value in enumerate(values[1000:]):
            result = detector.process_step(
                start + timedelta(minutes=index), float(value)
            )
            if result.is_anomalous:
                detections.append(index + 1000)
        self.assertTrue(all(any(start <= point <= end for point in detections) for start, end in windows))


if __name__ == "__main__":
    unittest.main()
