# Sentinel Dataset Evaluation

- Dataset directory: `C:\Users\ethan\OneDrive\Documents\GitHub\Class Omega\dataset`
- CSV files evaluated: 1
- Evaluation source: dataset folder only; no archive, synthetic, or external CSVs.
- Decision rule: score >= active dynamic threshold, followed by the configured point-magnitude gate and low-baseline suppression.

## Reference-label metrics

- Accuracy: 0.9963
- Precision: 1.0000
- Recall: 0.9583
- F1: 0.9787
- Confusion counts: TP=276, FP=0, FN=12, TN=2938
- Event-day precision / recall / F1: 1.0000 / 1.0000 / 1.0000

The target CSV has no row-level label file. For this report only, the 2014-04-11 date is treated as the positive reference window because the project requirements identify that anomaly period. These are date-level proxy metrics, not independently verified labels.

## Per-file results

### `art_daily_flatmiddle.csv`

- Observations: 4,032 (training 806, testing 3,226)
- Threshold crossings: 319
- Crossings blocked by point-magnitude gate: 31
- Low-baseline suppressions: 33
- Reported anomalies: 276
- Zero-valued anomaly alerts: 0
- Threshold/decision consistency checks: 3,226/3,226 passed
- Dynamic threshold: min 0.4128, median 0.4128, max 0.4159, final 0.4128
- Inference latency: mean 0.284 ms, p95 0.358 ms, max 1.365 ms
- Reference anomaly date(s): 2014-04-11
- Accuracy / precision / recall / F1: 0.9963 / 1.0000 / 0.9583 / 0.9787
- Event-day precision / recall / F1: 1.0000 / 1.0000 / 1.0000

## Interpretation

A threshold crossing is not silently discarded: the report separately counts crossings that are gated by point magnitude and those suppressed as baseline returns. A threshold candidate is excluded from adaptive normal-score history so a missed/gated candidate cannot raise its own future threshold.
