const maxDataPoints = 120;
const maxEvents = 100;
const axisColor = "rgba(148, 163, 184, 0.12)";
const labelColor = "#8393aa";
const chartFont = { family: "DM Sans, Segoe UI, sans-serif", size: 10 };

const sensorChart = new Chart(document.getElementById("sensorChart"), {
    type: "line",
    data: {
        labels: [],
        datasets: [
            {
                label: "Value",
                data: [],
                borderColor: "#64d8ca",
                backgroundColor: "rgba(94, 234, 212, 0.08)",
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.24,
                fill: true
            },
            {
                label: "Anomaly",
                data: [],
                borderColor: "#fb7185",
                backgroundColor: "#fb7185",
                pointRadius: 5,
                pointHoverRadius: 7,
                showLine: false
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        interaction: { intersect: false, mode: "index" },
        plugins: {
            legend: { labels: { color: labelColor, usePointStyle: true, boxWidth: 7, font: chartFont } },
            tooltip: { backgroundColor: "#101b2c", titleFont: chartFont, bodyFont: chartFont }
        },
        scales: {
            x: { display: false, grid: { display: false } },
            y: { grid: { color: axisColor }, ticks: { color: labelColor, font: chartFont, maxTicksLimit: 6 } }
        }
    }
});

const scoreChart = new Chart(document.getElementById("lossChart"), {
    type: "line",
    data: {
        labels: [],
        datasets: [
            {
                label: "Anomaly score",
                data: [],
                borderColor: "#f5a56b",
                backgroundColor: "rgba(245, 165, 107, 0.09)",
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.2,
                fill: true
            },
            {
                label: "Dynamic threshold",
                data: [],
                borderColor: "#91a9ff",
                borderDash: [5, 5],
                borderWidth: 1.5,
                pointRadius: 0,
                tension: 0
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        interaction: { intersect: false, mode: "index" },
        plugins: {
            legend: { labels: { color: labelColor, usePointStyle: true, boxWidth: 7, font: chartFont } },
            tooltip: { backgroundColor: "#101b2c", titleFont: chartFont, bodyFont: chartFont }
        },
        scales: {
            x: { display: false, grid: { display: false } },
            y: {
                min: 0,
                max: 1,
                grid: { color: axisColor },
                ticks: { color: labelColor, font: chartFont, maxTicksLimit: 6 }
            }
        }
    }
});

const statusBadge = document.getElementById("status");
const statusText = document.getElementById("status-text");
const scoreText = document.getElementById("score-text");
const thresholdText = document.getElementById("threshold-text");
const thresholdFloor = document.getElementById("threshold-floor");
const varianceText = document.getElementById("variance-text");
const latencyText = document.getElementById("latency-text");
const adaptationCount = document.getElementById("adaptation-count");
const lastAdaptation = document.getElementById("last-adaptation");
const stepCount = document.getElementById("step-count");
const alertCard = document.getElementById("alert-card");
const eventLog = document.getElementById("log");
const mlWeight = document.getElementById("ml-weight");
const mlWeightValue = document.getElementById("ml-weight-value");
const statWeightValue = document.getElementById("stat-weight-value");
const weightUpdateStatus = document.getElementById("weight-update-status");
const datasetName = document.getElementById("dataset-name");
const datasetStatus = document.getElementById("dataset-status");
const datasetFile = document.getElementById("dataset-file");
const uploadDatasetButton = document.getElementById("upload-dataset");
const decisionMode = document.getElementById("decision-mode");
const decisionState = document.getElementById("decision-state");
const decisionSummary = document.getElementById("decision-summary");
let activeSocket = null;
let reconnectTimer = null;

function updateScoreWeights() {
    const autoencoderWeight = Number(mlWeight.value) / 100;
    mlWeightValue.textContent = `${Math.round(autoencoderWeight * 100)}%`;
    statWeightValue.textContent = `${Math.round((1 - autoencoderWeight) * 100)}%`;
    if (activeSocket?.readyState === WebSocket.OPEN) {
        activeSocket.send(JSON.stringify({
            type: "score_weights",
            autoencoder_weight: autoencoderWeight
        }));
        weightUpdateStatus.textContent = "Applied";
    } else {
        weightUpdateStatus.textContent = "Applies when connected";
    }
}

function setConnection(state, label) {
    statusBadge.className = `connection ${state}`;
    statusBadge.querySelector("span:last-child").textContent = label;
}

function appendEvent(data) {
    const empty = eventLog.querySelector(".empty-state");
    if (empty) empty.remove();

    const entry = document.createElement("article");
    entry.className = "event-item";
    const badge = document.createElement("span");
    badge.className = "event-badge";
    badge.textContent = "ANOMALY";
    const copy = document.createElement("div");
    copy.className = "event-copy";
    const title = document.createElement("strong");
    const timestamp = data.time || `Point ${data.row_index ?? data.step ?? "—"}`;
    title.textContent = `${timestamp} · row ${data.row_index ?? "—"} · value ${Number(data.value).toFixed(4)} · score ${Number(data.anomaly_score).toFixed(3)}`;
    const evidence = document.createElement("p");
    evidence.textContent = data.evidence || "Anomaly detected.";
    const details = data.details || {};
    const explanation = document.createElement("p");
    explanation.className = "event-details";
    explanation.textContent = [
        `Mode ${details.mode || data.detection_mode || "hybrid"}`,
        `statistics ${formatNumber(details.statistical_score, 3)}`,
        `ML ${formatNumber(details.autoencoder_score, 3)}`,
        `MSE ${formatNumber(details.reconstruction_mse, 5)}`,
        `point deviation ${formatNumber(details.point_deviation, 4)}`,
        `point threshold ${formatNumber(details.point_threshold, 4)}`,
        `decision threshold ${formatNumber(details.decision_threshold, 3)}`
    ].join(" · ");
    copy.append(title, evidence, explanation);
    entry.append(badge, copy);
    eventLog.prepend(entry);
    while (eventLog.children.length > maxEvents) eventLog.lastElementChild.remove();
}

function formatNumber(value, digits = 3) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric.toFixed(digits) : "—";
}

function updateDecision(data) {
    const details = data.details || {};
    const anomalous = data.label === "ANOMALOUS";
    const mode = details.mode || data.detection_mode || "hybrid";
    decisionMode.textContent = `${mode.replaceAll("_", " ")} detection`;
    decisionState.textContent = anomalous
        ? "Anomaly reported"
        : details.baseline_suppressed
            ? "Baseline return suppressed"
            : details.point_trigger === false
                ? "Score/magnitude gate not met"
                : "Within calibrated baseline";
    decisionSummary.textContent = data.evidence || "Waiting for detector evidence.";
    document.getElementById("latest-stat-score").textContent =
        formatNumber(details.statistical_score);
    document.getElementById("latest-ml-score").textContent =
        formatNumber(details.autoencoder_score);
    document.getElementById("latest-point-deviation").textContent =
        formatNumber(details.point_deviation, 4);
    document.getElementById("latest-point-threshold").textContent =
        formatNumber(details.point_threshold, 4);
    document.getElementById("latest-mse").textContent =
        formatNumber(details.reconstruction_mse, 5);
}

function updateCharts(data) {
    const label = data.time ?? data.step ?? "";
    const values = [
        Number(data.value),
        data.label === "ANOMALOUS" ? Number(data.value) : null
    ];
    const charts = [
        [sensorChart, values],
        [scoreChart, [Number(data.anomaly_score), Number(data.threshold)]]
    ];
    for (const [chart, points] of charts) {
        chart.data.labels.push(label);
        points.forEach((value, index) => chart.data.datasets[index].data.push(value));
        while (chart.data.labels.length > maxDataPoints) {
            chart.data.labels.shift();
            chart.data.datasets.forEach((dataset) => dataset.data.shift());
        }
        chart.update("none");
    }
}

function handleMessage(event) {
    const data = JSON.parse(event.data);
    const score = Number(data.anomaly_score ?? 0);
    const threshold = Number(data.threshold ?? 0.05);
    const variance = Number(data.rolling_variance ?? 0);
    const latency = Number(data.latency_ms ?? 0);
    if (data.dataset) {
        datasetName.textContent = data.dataset;
        datasetStatus.textContent =
            `Streaming observation ${Number(data.row_index ?? 0).toLocaleString()} of ` +
            `${Number(data.total_rows ?? 0).toLocaleString()}.`;
    }
    if (data.autoencoder_weight != null) {
        const weight = Math.round(Number(data.autoencoder_weight) * 100);
        if (document.activeElement !== mlWeight) mlWeight.value = String(weight);
        mlWeightValue.textContent = `${weight}%`;
        statWeightValue.textContent = `${100 - weight}%`;
    }
    scoreText.textContent = score.toFixed(3);
    thresholdText.textContent = threshold.toFixed(3);
    thresholdFloor.textContent = Number(data.threshold_floor ?? 0.05).toFixed(3);
    varianceText.textContent = variance.toFixed(4);
    latencyText.innerHTML = `${latency.toFixed(2)} <small>ms</small>`;
    adaptationCount.textContent = String(data.adaptation_count ?? 0);
    lastAdaptation.textContent = data.last_adaptation
        ? new Date(data.last_adaptation).toLocaleString()
        : "Not yet adapted";
    stepCount.textContent = data.step == null ? "—" : Number(data.step).toLocaleString();

    const anomalous = data.label === "ANOMALOUS";
    statusText.textContent = anomalous ? "ANOMALOUS" : "NORMAL";
    statusText.style.color = anomalous ? "#fb7185" : "#46dfb2";
    alertCard.classList.toggle("danger", anomalous);
    updateDecision(data);
    updateCharts(data);
    if (anomalous) appendEvent(data);
}

function connect() {
    if (reconnectTimer) clearTimeout(reconnectTimer);
    setConnection("", "Connecting");
    const scheme = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.hostname || "localhost";
    const socket = new WebSocket(`${scheme}//${host}:8000/ws`);
    activeSocket = socket;

    socket.onopen = () => {
        if (activeSocket === socket) {
            setConnection("connected", "Live stream active");
            updateScoreWeights();
        }
    };
    socket.onmessage = (event) => {
        try {
            handleMessage(event);
        } catch (error) {
            console.error("Could not render Sentinel stream update:", error);
        }
    };
    socket.onerror = () => setConnection("disconnected", "Stream connection error");
    socket.onclose = (event) => {
        if (activeSocket !== socket) return;
        if (event.code === 1000) {
            setConnection("disconnected", "Dataset complete");
        } else {
            setConnection("disconnected", "Disconnected");
            reconnectTimer = setTimeout(connect, 2500);
            setConnection("disconnected", "Reconnecting…");
        }
    };
}

document.getElementById("reconnect").addEventListener("click", () => {
    if (activeSocket && activeSocket.readyState < WebSocket.CLOSING) {
        activeSocket.close();
    } else {
        connect();
    }
});
document.getElementById("clear-log").addEventListener("click", () => {
    eventLog.replaceChildren();
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "Anomaly evidence will appear here as events are detected.";
    eventLog.append(empty);
});

mlWeight.addEventListener("input", updateScoreWeights);
document.getElementById("choose-dataset").addEventListener("click", () => {
    datasetFile.click();
});
datasetFile.addEventListener("change", () => {
    const file = datasetFile.files?.[0];
    if (!file) return;
    datasetName.textContent = file.name;
    datasetStatus.textContent = `${(file.size / 1024).toFixed(1)} KB selected; minimum 61 finite rows.`;
    uploadDatasetButton.disabled = false;
});
uploadDatasetButton.addEventListener("click", async () => {
    const file = datasetFile.files?.[0];
    if (!file) return;
    uploadDatasetButton.disabled = true;
    datasetStatus.textContent = "Reading, training, and switching the live stream…";
    try {
        const host = window.location.hostname || "localhost";
        const apiScheme = window.location.protocol === "https:" ? "https:" : "http:";
        const response = await fetch(
            `${apiScheme}//${host}:8000/dataset?filename=${encodeURIComponent(file.name)}`,
            {
                method: "POST",
                headers: { "Content-Type": "text/csv" },
                body: await file.arrayBuffer()
            }
        );
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.detail || "Dataset upload failed.");
        }
        datasetName.textContent = result.dataset;
        datasetStatus.textContent =
            `${Number(result.observations).toLocaleString()} observations · ` +
            `${Number(result.training_observations).toLocaleString()} training · ` +
            `${Number(result.streaming_observations).toLocaleString()} streaming`;
        eventLog.replaceChildren();
        const empty = document.createElement("div");
        empty.className = "empty-state";
        empty.textContent = "Anomaly evidence will appear here as events are detected.";
        eventLog.append(empty);
        updateScoreWeights();
        if (!activeSocket || activeSocket.readyState >= WebSocket.CLOSING) connect();
    } catch (error) {
        datasetStatus.textContent = error.message || "Dataset upload failed.";
        console.error("Could not load custom Sentinel dataset:", error);
    } finally {
        uploadDatasetButton.disabled = false;
    }
});
connect();
